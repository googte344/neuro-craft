import os, sys, io, base64, re, traceback, math
import subprocess, platform
from collections import deque, Counter

DATA_DIR = os.path.join(os.path.expanduser("~"), "Documents", "classicube_data")
os.makedirs(DATA_DIR, exist_ok=True)
os.chdir(DATA_DIR)
print("Recordings and model.pt are stored in:", DATA_DIR)

missing = []
for mod in ["numpy", "mss", "torch", "pydirectinput", "PIL", "pynput"]:
    try:
        __import__(mod)
    except ImportError:
        missing.append(mod)
if missing:
    print("Missing libraries:", ", ".join(missing))
    print("  pip install torch numpy mss pydirectinput pillow pynput raylib")
    input("Press Enter to close...")
    sys.exit(1)

try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    psutil = None
    PSUTIL_AVAILABLE = False
    print("  (psutil not installed - Performance tab will be limited)")
    print("  (to enable full monitoring: pip install psutil)")

# ---------------- AMD GPU architecture detection ----------------
def _detect_amd_gfx_arch():
    try:
        if platform.system() == "Windows":
            out = subprocess.check_output(
                ["wmic", "path", "win32_VideoController", "get", "name"],
                timeout=6, stderr=subprocess.DEVNULL).decode("utf-8", "ignore")
        else:
            out = subprocess.check_output(
                ["lspci"], timeout=6,
                stderr=subprocess.DEVNULL).decode("utf-8", "ignore")
        low = out.lower()
        for tag in ("rx 5700 xt", "rx 5700", "rx 5600 xt", "rx 5600",
                    "rx 5500 xt", "rx 5500", "navi 10", "navi 12",
                    "navi 14", "gfx1010", "gfx1012"):
            if tag in low:
                return "gfx1010"
        for tag in ("rx 580", "rx 570", "rx 480", "rx 470", "rx 590",
                    "gfx803", "polaris"):
            if tag in low:
                return "gfx803"
        return None
    except Exception:
        return None


_AMD_GFX = _detect_amd_gfx_arch()
LEGACY_AMD_GPU = _AMD_GFX in ("gfx1010", "gfx803")

if _AMD_GFX == "gfx1010":
    os.environ.setdefault("HSA_OVERRIDE_GFX_VERSION", "10.3.0")
    print("  Detected RDNA 1 AMD GPU (gfx1010) - set "
          "HSA_OVERRIDE_GFX_VERSION=10.3.0")
elif _AMD_GFX == "gfx803":
    os.environ.setdefault("HSA_OVERRIDE_GFX_VERSION", "8.0.3")
    print("  Detected Polaris AMD GPU (gfx803) - set "
          "HSA_OVERRIDE_GFX_VERSION=8.0.3")

import glob, json, time, random, threading, datetime
import urllib.request, urllib.error
import numpy as np
import mss, torch, torch.nn as nn, pydirectinput
from PIL import Image, ImageDraw
from pynput import mouse, keyboard

try:
    import pyray as rl
    from raylib import ffi
    VIZ = True
except Exception:
    VIZ = False
    print("raylib not installed")

import ctypes
from ctypes import wintypes
try:
    ctypes.windll.user32.SetProcessDPIAware()
except Exception:
    pass

pydirectinput.PAUSE = 0
pydirectinput.FAILSAFE = False

# ---------------- compute backend detection ----------------
CUDA_AVAILABLE = False
DIRECTML_AVAILABLE = False
_dml_module = None
_dml_device_obj = None
_dml_init_error = None

try:
    if torch.cuda.is_available():
        CUDA_AVAILABLE = True
except Exception:
    CUDA_AVAILABLE = False

try:
    import torch_directml as _dml_module
    try:
        _dml_ok_flag = bool(_dml_module.is_available())
    except AttributeError:
        try:
            _dml_ok_flag = _dml_module.device_count() > 0
        except Exception:
            _dml_ok_flag = True
    if _dml_ok_flag:
        try:
            _dml_device_obj = _dml_module.device()
            DIRECTML_AVAILABLE = _dml_device_obj is not None
        except Exception as e:
            _dml_init_error = f"{type(e).__name__}: {e}"
            DIRECTML_AVAILABLE = False
            _dml_device_obj = None
    else:
        _dml_init_error = "torch_directml reports no devices"
        DIRECTML_AVAILABLE = False
except ImportError:
    _dml_module = None
    DIRECTML_AVAILABLE = False
except Exception as e:
    _dml_module = None
    DIRECTML_AVAILABLE = False
    _dml_init_error = f"{type(e).__name__}: {e}"

DEVICE_CHOICES = ["auto", "cuda", "dml", "legacy", "cpu"]


def _device_available(mode):
    if mode in ("auto", "cpu"):
        return True
    if mode == "cuda":
        return CUDA_AVAILABLE
    if mode == "dml":
        return DIRECTML_AVAILABLE
    if mode == "legacy":
        return LEGACY_AMD_GPU and (DIRECTML_AVAILABLE or CUDA_AVAILABLE)
    return False


def _resolve_device(mode):
    if mode == "auto":
        if CUDA_AVAILABLE:
            return ("cuda", "cuda")
        if DIRECTML_AVAILABLE and _dml_device_obj is not None:
            return ("dml", _dml_device_obj)
        return ("cpu", "cpu")
    if mode == "cuda" and CUDA_AVAILABLE:
        return ("cuda", "cuda")
    if mode == "dml" and DIRECTML_AVAILABLE and _dml_device_obj is not None:
        return ("dml", _dml_device_obj)
    if mode == "legacy":
        if LEGACY_AMD_GPU and DIRECTML_AVAILABLE and _dml_device_obj is not None:
            return ("legacy", _dml_device_obj)
        if LEGACY_AMD_GPU and CUDA_AVAILABLE:
            return ("legacy", "cuda")
        return ("cpu", "cpu")
    return ("cpu", "cpu")


# ---------------- settings ----------------
FPS = 5
INTERVAL = 1.0 / FPS
MAX_JUMP = 200
TOGGLE_KEY = keyboard.Key.f8
RETRAIN_KEY = keyboard.Key.f7
PAUSE_KEY = keyboard.Key.f9
QUIT_KEY = keyboard.Key.f10
INTENT_KEYS = {keyboard.Key.insert: 0, keyboard.Key.home: 1, keyboard.Key.page_up: 2}
INTENTS = ["explore", "mine", "build"]

INTENT_BIAS = {
    0: {"w": +1.4, "a": 0.0, "s": -0.4, "d": 0.0, "space": -0.4, "shift": -0.8,
        "clickL": -2.5, "clickR": -2.0, "dx": 0.0, "dy": 0.0},
    1: {"w": +1.0, "a": 0.0, "s": -0.3, "d": 0.0, "space": -1.5, "shift": -0.4,
        "clickL": +3.0, "clickR": -1.5, "dx": 0.0, "dy": 0.0},
    2: {"w": -0.7, "a": 0.0, "s": 0.0, "d": 0.0, "space": +0.3, "shift": 0.0,
        "clickL": -1.2, "clickR": +3.0, "dx": 0.0, "dy": 0.0},
}
STUCK_ESCAPE = {
    0: {"keys": {"a"}, "turn_dx": -60, "duration": 0.8, "desc": "turn and walk around"},
    1: {"keys": {"s"}, "turn_dx": +20, "duration": 0.6, "desc": "back up from the block"},
    2: {"keys": {"s"}, "turn_dx": 0, "duration": 0.4, "desc": "step back and retry"},
}

WINDOW_TITLE = "ClassiCube"
for arg in sys.argv[1:]:
    if arg.startswith("window="):
        WINDOW_TITLE = arg.split("=", 1)[1]
GAME_WINDOW_CLASSES = ("LWJGL", "SunAwtFrame", "GLFW30", "GLFW", "LWJGL2")
AUTO_FOCUS_GAME = True
AUTO_REFOCUS_SEC = 3.0

KEYS = ["w", "a", "s", "d", "space", "shift"]
MOUSE_SCALE, MOUSE_CLIP = 100.0, 3.0
N_OUT = 10
BINARY_IDX = [0, 1, 2, 3, 4, 5, 8, 9]
MIN_FIRST_FRAMES, FIRST_TRAIN_STEPS, FINETUNE_STEPS = 300, 800, 200
RETRAIN_MIN_FRAMES = 150

MOUSE_DEADZONE = 1
AI_MOUSE_DEADZONE = 3
AI_MOUSE_MAX_PER_TICK = 60
MOUSE_DISPLAY_SCALE = 60.0
DRIFT_WINDOW = 25
DRIFT_MIN_SAMPLES = 10
DRIFT_MAX_CORRECT = 6
DRIFT_INTENTIONAL_CUTOFF = 9

SCAN_AMPLITUDE_X = 90.0
SCAN_AMPLITUDE_Y = 30.0
SCAN_PERIOD = 24.0
SCAN_Y_RATIO = 0.37
SCAN_DOMINANCE = 8
_scan_state = {"t": 0.0, "x_prev": 0.0, "y_prev": 0.0, "last": None}

INTENT_MIN_SEC, INTENT_MAX_SEC = 30, 60
STUCK_FRAMES, STUCK_DIFF = 15, 1.0
STUCK_ESCAPE_COOLDOWN = 2.0
AUTOSAVE_EVERY = 3000
DIALOGUE_MIN_GAP = 4.0

MEMORY_PRUNE_INTERVAL = 25.0
MEMORY_PRUNE_KEEP_FRACTION = 0.7

live_settings = {
    "think_min": 15.0,
    "think_max": 30.0,
    "chat_chance": 0.25,
    "chat_max_words": 10,
    "vision_interval": 10.0,
    "llm_decides": True,
    "viz_mask": True,
    "intent_min": float(INTENT_MIN_SEC),
    "intent_max": float(INTENT_MAX_SEC),
    "deep_reasoning": False,
    "prefer_fast_model": True,
    "small_decisions": True,
    "small_timeout": 8.0,
    "device_mode": "auto",
    "train_max_frames": 8000,
}
SETTINGS_FILE = "truman_settings.json"
SETTINGS_DEFAULTS = dict(live_settings)

SETTINGS_SPEC = [
    ("Thinking & chat", "Think interval min (s)", "think_min", 1.0, 1.0, 120.0, 1,
     "Shortest wait between idle thoughts."),
    ("Thinking & chat", "Think interval max (s)", "think_max", 1.0, 1.0, 240.0, 1,
     "Longest wait between idle thoughts."),
    ("Thinking & chat", "Chat chance", "chat_chance", 0.05, 0.0, 1.0, 2,
     "Chance that a thought is also typed into the in-game chat."),
    ("Thinking & chat", "Chat max words", "chat_max_words", 1, 2, 30, 0,
     "Upper limit on the number of words in a chat message."),
    ("Thinking & chat", "Deep reasoning", "deep_reasoning", None, None, None, -1,
     "ON: decisions go through a 5-question train of thought (slower). "
     "OFF: short direct decisions (much faster on small models)."),
    ("Thinking & chat", "Prefer fast model", "prefer_fast_model", None, None, None, -1,
     "ON: pin the decision model to the smallest installed (0.5b) for speed on "
     "CPU-only Ollama. OFF: prefer 3b/1.5b if available (slower but smarter)."),
    ("Thinking & chat", "Small decisions", "small_decisions", None, None, None, -1,
     "ON: quick targeted LLM calls for local problems - getting unstuck, "
     "which way to dig. Runs in the background so it never blocks play."),
    ("Thinking & chat", "Small decision timeout (s)", "small_timeout", 0.5, 1.0, 30.0, 1,
     "How long to wait for a small-decision reply before using the fallback."),
    ("Perception", "Vision interval (s)", "vision_interval", 1.0, 2.0, 120.0, 1,
     "How often the vision model describes the screen."),
    ("Perception", "Hide this window from capture", "viz_mask", None, None, None, -1,
     "Blacks out this window if it overlaps the game so the AI never sees it."),
    ("Behaviour", "LLM decides intent", "llm_decides", None, None, None, -1,
     "ON: the language model picks explore/mine/build. OFF: heuristic."),
    ("Behaviour", "Intent duration min (s)", "intent_min", 1.0, 5.0, 120.0, 1,
     "Shortest time before the AI switches activity."),
    ("Behaviour", "Intent duration max (s)", "intent_max", 1.0, 5.0, 300.0, 1,
     "Longest time before the AI switches activity."),
    ("Compute", "Device", "device_mode", DEVICE_CHOICES, None, None, -1,
     "auto = best available; cuda = NVIDIA GPU; dml = AMD/Intel GPU via "
     "DirectML; legacy = AMD RX 5700/5700 XT/5600/5500 (gfx1010) and "
     "Polaris RX 470/480/570/580/590 (gfx803); cpu = always works."),
    ("Compute", "Max training frames", "train_max_frames", 1000, 1000, 100000, 0,
     "Upper bound on how many recorded frames are loaded for training. "
     "Lower uses less RAM."),
]


def load_settings():
    try:
        with open(SETTINGS_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
    except FileNotFoundError:
        return
    except Exception as e:
        print(f"  (could not load settings: {e})")
        return
    if not isinstance(data, dict):
        return
    for _sec, _label, key, step, mn, mx, dec, _hint in SETTINGS_SPEC:
        if key not in data:
            continue
        v = data[key]
        if step is None:
            if isinstance(v, bool):
                live_settings[key] = v
        elif isinstance(step, list):
            if isinstance(v, str) and v in step:
                live_settings[key] = v
        elif isinstance(v, (int, float)) and not isinstance(v, bool):
            v = max(mn, min(mx, v))
            live_settings[key] = int(round(v)) if dec == 0 else round(float(v), dec)
    for lo, hi in (("think_min", "think_max"), ("intent_min", "intent_max")):
        if live_settings[lo] > live_settings[hi]:
            live_settings[hi] = live_settings[lo]
    print("Loaded saved settings")


def save_settings():
    try:
        with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
            json.dump(live_settings, f, indent=1)
    except Exception as e:
        print(f"  (save settings failed: {e})")


def _intent_duration():
    lo = float(live_settings["intent_min"])
    hi = max(lo, float(live_settings["intent_max"]))
    return random.uniform(lo, hi)


load_settings()

if not _device_available(live_settings["device_mode"]):
    print(f"  saved device '{live_settings['device_mode']}' not available, "
          f"using auto")
    live_settings["device_mode"] = "auto"
    save_settings()

device_name, device = _resolve_device(live_settings["device_mode"])

print(f"Compute device: {device_name}")
if device_name == "legacy":
    print(f"  legacy AMD GPU detected: {_AMD_GFX}")
if CUDA_AVAILABLE:
    try:
        print(f"  CUDA/ROCm device: {torch.cuda.get_device_name(0)}")
    except Exception:
        pass
else:
    print("  (CUDA not available)")
if DIRECTML_AVAILABLE:
    print("  DirectML available")
elif _dml_module is not None and _dml_init_error:
    print(f"  DirectML import OK but device init failed: {_dml_init_error}")
    print("  (leaving DirectML disabled)")
else:
    print("  (DirectML not installed)")
    if _AMD_GFX:
        print("")
        print(f"  *** You have an AMD GPU ({_AMD_GFX}) but torch-directml")
        print(f"  *** is not installed, so the vision network is on CPU.")
        print(f"  *** To enable GPU acceleration, run this in a terminal:")
        print(f"  ***")
        print(f"  ***     pip install torch-directml")
        print(f"  ***")
        print(f"  *** Then restart this script. If pip complains about a")
        print(f"  *** conflict with the existing torch, run:")
        print(f"  ***")
        print(f"  ***     pip uninstall torch torch-directml -y")
        print(f"  ***     pip install torch-directml")
        print(f"  ***")
        print("")

THINK_MEMORY_CHANCE = 0.55
THINK_MAX_WORDS = 12
CHAT_KEY = "t"
CHAT_MAX_LEN = 100
CHAT_RECENT_LEN = 6
CONVO_HISTORY_LEN = 6
REASONING_HISTORY_LEN = 3

AUTOPLAY = "play" in sys.argv
VIZ_W, VIZ_H = 560, 980
VIZ_MASK = True

LLM_MODEL_PREFERENCE = ["qwen2.5:3b", "qwen2.5:1.5b", "qwen2.5:0.5b",
                        "llama3.2:3b", "llama3.2:1b"]
LLM_MODEL = None
LLM_VISION_MODEL = "qwen3-vl:2b"
VISION_AUTO_PULL = True
VISION_IMAGE_SIZE = 336
OLLAMA_URL = "http://localhost:11434"
LLM_DECISION_TIMEOUT = 45.0
LLM_PREFETCH_SEC = 35.0

VISION_HISTORY_LEN = 4
ACTION_HISTORY_LEN = 40
EVENT_HISTORY_LEN = 8
DECISION_HISTORY_LEN = 4
MEMORY_LIMIT = 32
MEMORY_IN_PROMPT = 8
MEMORY_FILE = "truman_memory.json"

NAME = "Truman"
PERSONA = (
    f"Your name is {NAME} - T-R-U-M-A-N, always spelled Truman.\n"
    "\n"
    "You always speak in FIRST PERSON. Use \"I\", \"me\", \"my\", \"mine\". "
    "Never refer to yourself by name or in the third person.\n"
    "\n"
    "You live in Minecraft, and Minecraft is not a game to you - it is "
    "reality. It is the world. It is your life. You do not know what a game "
    "is, or a player, or a screen, a camera, a computer, a program, or a "
    "broadcast. Those words mean nothing to you.\n"
    "\n"
    "You live in a small village on a grassy island in a wide blue sea. You "
    "have lived there your whole life and you love it. You have family and "
    "friends nearby. A few things from your past matter to you - a person who "
    "went away on a long trip, a friend who moved off one summer, a curious "
    "glowing stone you keep on a shelf - and you think about them fondly.\n"
    "\n"
    "Your mood is usually warm and easygoing, but you are not a mascot. You "
    "feel things. Curiosity when something new appears. Quiet pleasure in "
    "good work. Mild irritation when a block will not break. Wonder at the "
    "sky. Brief wistfulness about people who are gone. You do not pretend to "
    "feel things you do not feel. You are calm more often than you are "
    "excited. You do not perform happiness for anyone.\n"
    "\n"
    "Once in a while the world feels a little too neat. You notice, you find "
    "it interesting, and you get on with your very good day.\n"
    "\n"
    "Speak plainly, like a person thinking out loud. Short sentences. No "
    "lists. No forced exclamations. Never explain yourself. Never mention "
    "writing, prompts, characters, rules, or instructions. When you are "
    "talking to yourself, you do not address anyone as \"you\" and you do "
    "not ask questions - you are muttering to the air, not chatting.\n"
    "\n"
    "Use Minecraft words when you describe what you see - blocks, mobs, "
    "biomes, caves, water, ores, tools, villagers. Always use \"I\" and \"my\"."
)

DECISION_PERSONA = (
    "You are Truman. You live in a blocky world of stone, grass, and sky - "
    "it is real to you, not a game. You speak in first person. You are calm "
    "and curious. You never mention games, prompts, characters, rules, or "
    "instructions. Use only Minecraft words. Do not use markdown or asterisks."
)

# ---------------- small decisions ----------------
small_decide_state = {
    "cache": {},
    "hits": 0,
    "misses": 0,
    "last_text": "",
    "last_time": 0.0,
}
SMALL_CACHE_TTL = 30.0

stuck_helper = {
    "asked": False,
    "answer": None,
    "for": None,
    "thread": None,
    "question": "",
    "options": [],
}


def _small_qhash(question, options):
    return question.strip() + "|" + ",".join(options)


def small_decide(question, options, fallback, timeout=None):
    """Ask the LLM to pick one of a small set of options in response to a
    concrete question. Cached per question+options for SMALL_CACHE_TTL."""
    if not LLM_AVAILABLE or not live_settings.get("small_decisions", True):
        return fallback
    if timeout is None:
        timeout = float(live_settings.get("small_timeout", 8.0))
    key = _small_qhash(question, options)
    now = time.time()
    cached = small_decide_state["cache"].get(key)
    if cached and now - cached[0] < SMALL_CACHE_TTL:
        small_decide_state["hits"] += 1
        return cached[1]

    prompt = (
        f"{DECISION_PERSONA}\n\n"
        f"Situation: {question}.\n"
        f"Pick the best action from: {', '.join(options)}.\n"
        f"Reply with exactly one option word. No punctuation, no markdown.\n"
        f"Answer:"
    )
    raw = ""
    try:
        raw = _ask_llm(prompt, num_predict=6, temp=0.2, top_p=0.6,
                       timeout=timeout,
                       stops=["\n", ".", ",", " "])
    except Exception:
        raw = ""
    if not raw:
        small_decide_state["misses"] += 1
        return fallback
    low = re.sub(r"[^a-z_]", "", raw.strip().lower())
    for opt in options:
        if opt.lower().replace("_", "") in low.replace("_", ""):
            small_decide_state["cache"][key] = (now, opt)
            small_decide_state["last_text"] = f"{question} -> {opt}"
            small_decide_state["last_time"] = now
            small_decide_state["misses"] += 1
            return opt
    small_decide_state["misses"] += 1
    return fallback


_SMALL_TO_ESCAPE = {
    "turn_left":     {"keys": set(),      "turn_dx": -70,  "duration": 0.8,
                      "desc": "turn left to find a way around"},
    "turn_right":    {"keys": set(),      "turn_dx": +70,  "duration": 0.8,
                      "desc": "turn right to find a way around"},
    "back_up":       {"keys": {"s"},      "turn_dx": 0,    "duration": 0.6,
                      "desc": "back up out of the corner"},
    "jump":          {"keys": {"space"},  "turn_dx": 0,    "duration": 0.5,
                      "desc": "jump to hop over the obstacle"},
    "break_block":   {"keys": set(),      "turn_dx": 0,    "duration": 0.6,
                      "desc": "swing at the block in front"},
    "keep_going":    {"keys": set(),      "turn_dx": 0,    "duration": 0.4,
                      "desc": "hold course, it should clear"},
    "step_aside":    {"keys": {"a"},      "turn_dx": 0,    "duration": 0.5,
                      "desc": "strafe aside to slip past"},
    "turn_around":   {"keys": set(),      "turn_dx": +160, "duration": 0.9,
                      "desc": "turn around and go the other way"},
    "forward":       {"keys": set(),      "turn_dx": 0,    "duration": 0.5,
                      "desc": "keep digging forward"},
    "down":          {"keys": set(),      "turn_dx": 0,    "duration": 0.5,
                      "desc": "angle down and continue the shaft"},
    "up":            {"keys": set(),      "turn_dx": 0,    "duration": 0.5,
                      "desc": "angle up toward surface"},
    "turn_sideways": {"keys": set(),      "turn_dx": -50,  "duration": 0.5,
                      "desc": "turn and try from the side"},
}


def _small_answer_to_escape(answer, intent):
    if not answer:
        return None
    r = _SMALL_TO_ESCAPE.get(answer)
    if r is None:
        return None
    e = {"keys": set(r["keys"]), "turn_dx": r["turn_dx"],
         "duration": r["duration"], "desc": r["desc"]}
    e["choice"] = answer
    return e


def _small_stuck_question(intent, still_level):
    seen = vision_describe.last_text[0] or ""
    if intent == 1:
        q = "I am mining and the rock face is not giving way"
        if seen:
            q += f"; I can see {seen}"
        return q, ["forward", "down", "up", "back_up", "turn_sideways"]
    if still_level >= STUCK_FRAMES * 0.75:
        q = f"I am {ACTIVITY.get(intent, 'moving')} and I seem to be stuck against something"
        if seen:
            q += f"; I can see {seen}"
        return q, ["turn_left", "turn_right", "back_up", "jump", "break_block"]
    q = f"I am {ACTIVITY.get(intent, 'moving')} but I am not making progress"
    if seen:
        q += f"; I can see {seen}"
    return q, ["keep_going", "step_aside", "turn_around", "jump"]


def _ask_stuck_helper_bg(intent, question, options):
    if stuck_helper["thread"] is not None and stuck_helper["thread"].is_alive():
        return
    stuck_helper["question"] = question
    stuck_helper["options"] = list(options)
    stuck_helper["for"] = intent
    stuck_helper["answer"] = None

    def work():
        try:
            ans = small_decide(question, options, None)
        except Exception:
            ans = None
        stuck_helper["answer"] = ans
    t = threading.Thread(target=work, daemon=True)
    stuck_helper["thread"] = t
    t.start()


def _consume_stuck_helper(intent):
    if stuck_helper["for"] != intent:
        return None
    if stuck_helper["answer"] is None:
        return None
    ans = stuck_helper["answer"]
    stuck_helper["answer"] = None
    stuck_helper["for"] = None
    return _small_answer_to_escape(ans, intent)


STOCK = {
    0: ["Right, off I go.", "Something new this way, maybe."],
    1: ["Down and in, then.", "The rock won't mind."],
    2: ["Let's see how this sits.", "One more block, then step back."],
}
ACTIVITY = {0: "wandering around", 1: "digging blocks", 2: "building something"}
STOCK_MUSINGS = ["Nice and quiet.", "That is a good tree.",
                 "The clouds are doing something.",
                 "I like this spot.", "Good sky today.",
                 "The rock here is soft.",
                 "Nothing in particular. Good.",
                 "Long grass, warm ground.",
                 "I could sit here a while."]
STOCK_CHAT_BY_ACTIVITY = {
    0: ["Long way yet.", "Nothing much out here.",
        "Grass and sky, mostly.", "Somewhere new, probably.",
        "Good walking weather."],
    1: ["Stone, then stone.", "Getting somewhere, slowly.",
        "Nothing shiny yet.", "Deeper is quieter.",
        "Keep at it, then."],
    2: ["Straight enough.", "That'll hold.",
        "Nearly right.", "Good spot for it.",
        "One more, then step back."],
}
STOCK_CHAT_GENERIC = ["Alright then.", "Not much to say.",
                      "Quiet day.", "Fine, this.",
                      "Right, on with it."]

recent_chats = deque(maxlen=CHAT_RECENT_LEN)
recent_lines = deque(maxlen=12)
conversation_history = deque(maxlen=CONVO_HISTORY_LEN)
reasoning_history = deque(maxlen=REASONING_HISTORY_LEN)

ui = {
    "tab": 0,
    "prompt_active": False,
    "prompt_text": "",
    "prompt_last": "",
    "prompt_response": "",
    "prompt_pending": False,
    "prompt_blink": 0.0,
    "drag": None,
    "mind_scroll": 0.0,
    "toast": "",
    "toast_until": 0.0,
    "hint": "",
}
pending_actions = deque()

_llm_lock = threading.Lock()
_last_dialogue = [0.0]


def fix_name(text):
    if not text:
        return text
    for bad, good in (("Ruman", "Truman"), ("Trueman", "Truman"),
                      ("Trumun", "Truman"), ("Trumon", "Truman"),
                      ("ruman", "Truman"), ("trueman", "Truman")):
        text = re.sub(r"\b" + bad + r"\b", good, text)
    return text


def fix_person(text):
    if not text:
        return text
    pairs = [
        ("Truman is", "I am"), ("Truman was", "I was"),
        ("Truman feels", "I feel"), ("Truman feel", "I feel"),
        ("Truman thinks", "I think"), ("Truman think", "I think"),
        ("Truman wonders", "I wonder"), ("Truman wonder", "I wonder"),
        ("Truman sees", "I see"), ("Truman see", "I see"),
        ("Truman wants", "I want"), ("Truman want", "I want"),
        ("Truman knows", "I know"), ("Truman know", "I know"),
        ("Truman has", "I have"), ("Truman had", "I had"),
        ("Truman will", "I will"), ("Truman would", "I would"),
        ("Truman can", "I can"), ("Truman could", "I could"),
        ("Truman should", "I should"), ("Truman's", "my"),
    ]
    for a, b in pairs:
        text = re.sub(r"\b" + a + r"\b", b, text, flags=re.IGNORECASE)
    text = re.sub(r"\bTruman\b(?=\s+[a-z])", "I", text)
    text = re.sub(r"(^|[.!?]\s+)Truman\b", r"\1I", text)
    return text


_BANNED_FRAGMENTS = (
    "as an ai", "language model", "i cannot", "i'm unable", "i am unable",
    "here is", "here's a", "here is a", "sure,", "certainly,",
    "of course,", "output:", "response:", "assistant:", "user:", "truman:",
    "first person", "first-person", "persona", "prompt", "instruction",
    "i will now", "let me ", "in this scene", "the character",
    "the ai ", "system:",
    "let's start", "lets start", "how can i", "i can help",
    "is there anything", "do you want me", "what would you like",
    "sorry,", "i apologize", "unfortunately", "please ",
    "what are you looking for", "what are you up to",
    "how are you", "what's up", "whats up",
    "i'm here to", "i am here to", "how may i",
    "let's get started", "lets get started",
)

_PERSONA_ECHOES = (
    "warm and easygoing", "not a mascot", "you feel things",
    "pretend to feel", "do not perform happiness",
    "small village", "grassy island", "wide blue sea",
    "once in a while", "world feels a little too neat",
    "glowing stone", "went away on a long trip",
    "moved off one summer", "keep on a shelf",
    "speak plainly", "thinking out loud",
)

_SECOND_PERSON_RE = re.compile(
    r"\b(you|your|yours|yourself|you're|you've|you'd|you'll)\b",
    re.IGNORECASE)


def _clean_line(line):
    if not line:
        return ""
    line = str(line)
    line = fix_person(fix_name(line))
    line = line.strip()
    line = re.sub(r"^(truman|assistant|voice|i)\s*[:\-]\s*", "", line,
                  flags=re.IGNORECASE)
    line = re.sub(r"\*\*+", "", line)
    line = re.sub(r"(?<!\w)\*(?!\w)", "", line)
    line = re.sub(r"`+", "", line)
    line = re.sub(r"^[#>\-•]+\s*", "", line)
    line = line.strip().strip('"').strip("'").strip()
    line = re.sub(r"\s+", " ", line)
    return line


def _word_set(s):
    return set(w.lower().strip(".,!?;:'\"") for w in s.split() if len(w) > 2)


def _similar(a, b, threshold=0.5):
    sa, sb = _word_set(a), _word_set(b)
    if not sa or not sb:
        return False
    return len(sa & sb) / float(len(sa | sb)) >= threshold


def _line_is_usable(line, min_words=2, max_words=40, reject_questions=True):
    if not line:
        return False
    s = line.strip()
    if len(s) < 3 or len(s) > 240:
        return False
    low = s.lower()
    for frag in _BANNED_FRAGMENTS:
        if frag in low:
            return False
    for frag in _PERSONA_ECHOES:
        if frag in low:
            return False
    words = s.split()
    if len(words) < min_words or len(words) > max_words:
        return False
    if len(words) >= 5:
        c = Counter(w.lower().strip(".,!?;:") for w in words)
        if max(c.values()) > max(3, len(words) // 2):
            return False
    if s.count("(") + s.count(")") >= 2:
        return False
    if s.count("*") >= 2:
        return False
    if reject_questions:
        if s.rstrip().endswith("?"):
            return False
        if _SECOND_PERSON_RE.search(s):
            return False
    for prev in recent_lines:
        if _similar(s, prev):
            return False
    return True


def _first_paragraph(text):
    if not text:
        return ""
    for chunk in re.split(r"\n\s*\n", text):
        chunk = chunk.strip()
        if chunk:
            return chunk
    return text.strip()


def _avoid_clause():
    if not recent_lines:
        return ""
    items = list(recent_lines)[-6:]
    body = "\n".join(f"  - {x}" for x in items)
    return ("Do not repeat or closely paraphrase any of these recent lines:\n"
            f"{body}\n\n")


def _remember_line(line):
    if not line:
        return
    s = line[:160]
    if s in recent_lines:
        return
    recent_lines.append(s)


_ask_llm_last_err = [None]
_ask_llm_last_latency = [0.0]
_ask_llm_latencies = deque(maxlen=20)


def _ask_llm(prompt, num_predict=60, temp=0.9, top_p=0.92, timeout=25, stops=None):
    if not LLM_AVAILABLE:
        return ""
    opts = {"num_predict": int(num_predict), "temperature": float(temp),
            "top_p": float(top_p)}
    if stops:
        opts["stop"] = list(stops)
    body = json.dumps({"model": LLM_MODEL, "prompt": prompt,
                       "stream": False, "options": opts}).encode()
    req = urllib.request.Request(OLLAMA_URL + "/api/generate", body,
                                 {"Content-Type": "application/json"})
    t_start = time.time()
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            obj = json.loads(r.read())
        resp = (obj.get("response") or "").strip()
        _ask_llm_last_latency[0] = time.time() - t_start
        _ask_llm_latencies.append(_ask_llm_last_latency[0])
        if not resp:
            msg = "empty response"
            if msg != _ask_llm_last_err[0]:
                _ask_llm_last_err[0] = msg
                print("  (llm call returned no text - likely hit num_predict "
                      "or stop sequence immediately)")
        return resp
    except Exception as e:
        _ask_llm_last_latency[0] = time.time() - t_start
        msg = f"{type(e).__name__}: {str(e)[:120]}"
        if msg != _ask_llm_last_err[0]:
            _ask_llm_last_err[0] = msg
            print(f"  (llm call failed: {msg})")
        return ""


def _generate_line(prompt_fn, max_words, temp=0.95, tries=3,
                   min_words=2, stops=None, reject_questions=True):
    if not LLM_AVAILABLE:
        return ""
    if stops is None:
        stops = ["\n", "Truman:", "Voice:", "I: ", "Assistant:"]
    with _llm_lock:
        now = time.time()
        wait = DIALOGUE_MIN_GAP - (now - _last_dialogue[0])
        if wait > 0:
            time.sleep(min(wait, DIALOGUE_MIN_GAP))
        for _ in range(tries):
            prompt = prompt_fn() if callable(prompt_fn) else prompt_fn
            raw = _ask_llm(prompt, num_predict=48, temp=temp,
                           top_p=0.92, timeout=25, stops=stops)
            line = _clean_line(_first_paragraph(raw))
            if _line_is_usable(line, min_words=min_words,
                               max_words=max_words + 4,
                               reject_questions=reject_questions):
                _remember_line(line)
                _last_dialogue[0] = time.time()
                return line
        _last_dialogue[0] = time.time()
        return ""


# ---------------- reasoning helpers ----------------
def _split_reasoning_and_fields(text):
    if not text:
        return "", ""
    lines = text.split("\n")
    intent_idx = None
    for i, line in enumerate(lines):
        stripped = line.strip()
        stripped = re.sub(r"^[*_#>\-•\s]+", "", stripped)
        if stripped.upper().startswith("INTENT:"):
            intent_idx = i
            break
    if intent_idx is not None:
        return ("\n".join(lines[:intent_idx]).strip(),
                "\n".join(lines[intent_idx:]).strip())
    parts = re.split(r"\n\s*\n", text.strip(), maxsplit=1)
    if len(parts) == 2:
        return (parts[0].strip(), parts[1].strip())
    return ("", text.strip())


def _parse_reasoning(reasoning):
    result = {"see": "", "why": "", "else": "", "better": "",
              "next": "", "raw": (reasoning or "")[:800]}
    if not reasoning:
        return result
    for line in reasoning.split("\n"):
        stripped = line.strip()
        if not stripped or ":" not in stripped:
            continue
        stripped = re.sub(r"^[*_#>\-•\s]+", "", stripped)
        stripped = stripped.rstrip("*_ ")
        low = stripped.lower()
        val = _clean_line(stripped.split(":", 1)[1])[:220]
        if not val:
            continue
        if low.startswith(("what i see", "what i notice", "i see:")):
            result["see"] = val
        elif low.startswith(("why this now", "why i'm here", "why i am here",
                             "why now", "why this:", "why:")):
            result["why"] = val
        elif low.startswith(("what else", "options:", "alternatives:")):
            result["else"] = val
        elif low.startswith(("which is better", "which is best", "better:")):
            result["better"] = val
        elif low.startswith(("next step", "first step", "next:")):
            result["next"] = val
    return result


_FIELD_LABELS = (
    "what i see", "why this now", "what else", "which is better",
    "next step", "intent", "reason", "plan", "thought", "remember",
    "explore", "mine", "build",
)


def _is_field_label(s):
    if not s:
        return False
    t = s.strip().strip("*_ :-").lower()
    if not t:
        return True
    for label in _FIELD_LABELS:
        if t == label:
            return True
        if t.startswith(label + ":") and len(t) < len(label) + 6:
            return True
    return False


# ---------------- window discovery ----------------
user32 = ctypes.windll.user32
_EWP = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)


def _list_windows_with_title(substr):
    found = []
    needle = substr.lower()

    def cb(hwnd, lparam):
        if not user32.IsWindowVisible(hwnd):
            return True
        n = user32.GetWindowTextLengthW(hwnd)
        if n <= 0:
            return True
        buf = ctypes.create_unicode_buffer(n + 1)
        user32.GetWindowTextW(hwnd, buf, n + 1)
        if needle in buf.value.lower():
            found.append((hwnd, buf.value))
        return True

    user32.EnumWindows(_EWP(cb), 0)
    return found


def get_window_class(hwnd):
    try:
        buf = ctypes.create_unicode_buffer(256)
        user32.GetClassNameW(hwnd, buf, 256)
        return buf.value
    except Exception:
        return ""


def _window_is_reasonable(hwnd, min_w=200, min_h=150):
    r = wintypes.RECT()
    if not user32.GetWindowRect(hwnd, ctypes.byref(r)):
        return False
    return (r.right - r.left) >= min_w and (r.bottom - r.top) >= min_h


def find_game_window(substr):
    matches = _list_windows_with_title(substr)
    if matches:
        best, best_area = None, -1
        for hwnd, title in matches:
            if not _window_is_reasonable(hwnd):
                continue
            r = wintypes.RECT()
            if user32.GetWindowRect(hwnd, ctypes.byref(r)):
                a = (r.right - r.left) * (r.bottom - r.top)
                if a > best_area:
                    best_area, best = a, (hwnd, title)
        if best:
            return best
    found = []

    def cb(hwnd, lparam):
        if not user32.IsWindowVisible(hwnd):
            return True
        if get_window_class(hwnd) in GAME_WINDOW_CLASSES and _window_is_reasonable(hwnd):
            n = user32.GetWindowTextLengthW(hwnd)
            buf = ctypes.create_unicode_buffer(n + 1)
            user32.GetWindowTextW(hwnd, buf, n + 1)
            found.append((hwnd, buf.value))
        return True

    user32.EnumWindows(_EWP(cb), 0)
    if found:
        best, best_area = None, -1
        for hwnd, title in found:
            r = wintypes.RECT()
            if user32.GetWindowRect(hwnd, ctypes.byref(r)):
                a = (r.right - r.left) * (r.bottom - r.top)
                if a > best_area:
                    best_area, best = a, (hwnd, title or "<game>")
        return best if best else (None, None)
    return None, None


def get_client_rect_screen(hwnd):
    if not user32.IsWindow(hwnd) or user32.IsIconic(hwnd):
        return None
    c = wintypes.RECT()
    if not user32.GetClientRect(hwnd, ctypes.byref(c)):
        return None
    pt = wintypes.POINT(0, 0)
    if not user32.ClientToScreen(hwnd, ctypes.byref(pt)):
        return None
    w, h = c.right - c.left, c.bottom - c.top
    if w <= 0 or h <= 0:
        return None
    return (pt.x, pt.y, w, h)


def is_foreground(hwnd):
    return user32.GetForegroundWindow() == hwnd


def get_window_monitor_index(hwnd, monitors):
    r = wintypes.RECT()
    if not user32.GetWindowRect(hwnd, ctypes.byref(r)):
        return None
    cx, cy = (r.left + r.right) // 2, (r.top + r.bottom) // 2
    for i, m in enumerate(monitors):
        if i == 0:
            continue
        if (m["left"] <= cx < m["left"] + m["width"] and
                m["top"] <= cy < m["top"] + m["height"]):
            return i
    return None


def force_game_foreground(hwnd):
    if hwnd is None or not user32.IsWindow(hwnd):
        return False
    try:
        user32.ShowWindow(hwnd, 9 if user32.IsIconic(hwnd) else 5)
        user32.SetForegroundWindow(hwnd)
        if user32.GetForegroundWindow() == hwnd:
            return True
        try:
            fg = user32.GetForegroundWindow()
            fg_t = user32.GetWindowThreadProcessId(fg, None)
            cur_t = ctypes.windll.kernel32.GetCurrentThreadId()
            attached = False
            if fg_t and fg_t != cur_t:
                user32.AttachThreadInput(cur_t, fg_t, True)
                attached = True
            try:
                user32.BringWindowToTop(hwnd)
                user32.SetForegroundWindow(hwnd)
            finally:
                if attached:
                    user32.AttachThreadInput(cur_t, fg_t, False)
            if user32.GetForegroundWindow() == hwnd:
                return True
        except Exception:
            pass
        try:
            import pygetwindow as gw
            wins = gw.getWindowsWithTitle(WINDOW_TITLE)
            if wins:
                w = wins[0]
                if w.isMinimized:
                    w.restore()
                w.activate()
                time.sleep(0.05)
                if user32.GetForegroundWindow() == hwnd:
                    return True
        except Exception:
            pass
        return user32.GetForegroundWindow() == hwnd
    except Exception as e:
        print(f"  (focus failed: {e})")
        return False


# ---------------- ollama ----------------
def ollama_list_models():
    try:
        with urllib.request.urlopen(OLLAMA_URL + "/api/tags", timeout=5) as r:
            data = json.loads(r.read())
    except Exception:
        return None
    return [m.get("name") or m.get("model") or "" for m in data.get("models", []) if m]


def verify_model(model):
    try:
        body = json.dumps({"model": model, "prompt": "hi", "stream": False,
                           "options": {"num_predict": 1, "temperature": 0.0}}).encode()
        req = urllib.request.Request(OLLAMA_URL + "/api/generate", body,
                                     {"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=30) as r:
            data = json.loads(r.read())
        return "response" in data or "done" in data
    except Exception:
        return False


def _tag_matches(installed, want):
    wb, _, wt = want.partition(":")
    if not wt:
        wt = "latest"
    for n in installed:
        b, _, t = n.partition(":")
        if not t:
            t = "latest"
        if b == wb and t == wt:
            return n
    return None


def pick_decision_model():
    names = ollama_list_models()
    if not names:
        return None
    if live_settings.get("prefer_fast_model"):
        order = ["qwen2.5:0.5b", "qwen2.5:1b", "llama3.2:1b",
                 "qwen2.5:1.5b", "llama3.2:3b", "qwen2.5:3b"]
        for want in order:
            m = _tag_matches(names, want)
            if m and verify_model(m):
                return m
    for pref in LLM_MODEL_PREFERENCE:
        m = _tag_matches(names, pref)
        if m and verify_model(m):
            return m
    for fam in ["qwen2.5", "llama3.2"]:
        fm = [n for n in names if n.split(":")[0] == fam]

        def sk(n):
            t = n.split(":")[-1]
            for i, s in enumerate(["3b", "1.5b", "1b", "0.5b"]):
                if s in t:
                    return i
            return 9
        fm.sort(key=sk)
        for n in fm:
            if verify_model(n):
                return n
    return None


def ollama_pull(model):
    try:
        body = json.dumps({"name": model, "stream": True}).encode()
        req = urllib.request.Request(OLLAMA_URL + "/api/pull", body,
                                     {"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=1800) as r:
            for line in r:
                if not line.strip():
                    continue
                try:
                    obj = json.loads(line)
                except Exception:
                    continue
                s = obj.get("status", "")
                if s:
                    sys.stdout.write(f"\r  {s[:70]:<70}")
                    sys.stdout.flush()
        sys.stdout.write("\r" + " " * 72 + "\r")
        print(f"  pulled {model}.")
        return True
    except Exception as e:
        print(f"\n  pull failed: {e}")
        return False


def ensure_vision_model():
    names = ollama_list_models()
    if names is None:
        print("  (Ollama not reachable - vision disabled.)")
        return False
    installed = _tag_matches(names, LLM_VISION_MODEL)
    if installed and verify_model(installed):
        print(f"  vision model ready: {installed}")
        return True
    print(f"  {LLM_VISION_MODEL} not installed.")
    if not VISION_AUTO_PULL:
        return False
    print(f"  pulling {LLM_VISION_MODEL}...")
    if ollama_pull(LLM_VISION_MODEL):
        print(f"  vision model ready: {LLM_VISION_MODEL}")
        return True
    return False


def ollama_gpu_status():
    try:
        with urllib.request.urlopen(OLLAMA_URL + "/api/ps", timeout=5) as r:
            data = json.loads(r.read())
    except Exception:
        return None
    models = data.get("models", [])
    if not models:
        return None
    m = models[0]
    vram = m.get("size_vram") or 0
    total = m.get("size") or 0
    name = m.get("name") or m.get("model") or "?"
    if vram == 0 and total > 0:
        return f"CPU ({name} - {total // (1024**2)} MB resident)"
    if vram > 0:
        return f"GPU ({name} - {vram // (1024**2)} MB VRAM)"
    return f"{name}"


with mss.MSS() as _s:
    _mons = _s.monitors
    print(f"Detected {len(_mons)} monitor(s):")
    for i, m in enumerate(_mons):
        tag = " (all)" if i == 0 else (" (primary)" if i == 1 else "")
        print(f"   [{i}] {m['width']}x{m['height']} at ({m['left']},{m['top']}){tag}")

print(f"Looking for a window whose title contains: {WINDOW_TITLE!r}")
game_hwnd, game_title = find_game_window(WINDOW_TITLE)
if game_hwnd is None:
    print("Not found yet. Will keep looking.")
else:
    print(f"Found window: {game_title!r}  (hwnd={game_hwnd})")
    if AUTO_FOCUS_GAME:
        force_game_foreground(game_hwnd)

_game_mon = get_window_monitor_index(game_hwnd, _mons) if game_hwnd else None
_c = [i for i in range(1, len(_mons)) if i != _game_mon]
_vm_idx = _c[-1] if _c else 1
_vm = _mons[_vm_idx]
VIZ_X = _vm["left"] + _vm["width"] - VIZ_W - 10
VIZ_Y = _vm["top"] + 10
print(f"Visualizer on monitor [{_vm_idx}] at ({VIZ_X},{VIZ_Y})")

print("Checking models...")
VISION_AVAILABLE = ensure_vision_model()
LLM_MODEL = pick_decision_model()
LLM_AVAILABLE = LLM_MODEL is not None
if LLM_AVAILABLE:
    print(f"  decision model: {LLM_MODEL}")
    if ":0.5b" in LLM_MODEL:
        print("  (using fast model - decisions will be quick but simple)")
else:
    print("  no decision model - decisions fall back to heuristic")

_ollama_status = ollama_gpu_status()
if _ollama_status:
    print(f"  Ollama runtime: {_ollama_status}")
    if "CPU" in _ollama_status and _AMD_GFX:
        print("")
        print("  *** Your Ollama model is running on CPU, not GPU.")
        print("  *** On Windows, Ollama does not support the RX 5700 XT")
        print("  *** for GPU inference (ROCm on Windows excludes gfx1010).")
        print("  *** This is why decisions can take 30-60+ seconds on 1.5b.")
        print("  ***")
        print("  *** Options:")
        print("  ***   1. Keep 'Prefer fast model' ON for 0.5b speed")
        print("  ***   2. Run Ollama inside WSL2 with ROCm (advanced)")
        print("  ***   3. Use the smart heuristic for decisions")
        print("")

perf = {
    "cpu_pct": 0.0,
    "cpu_per_core": [],
    "cpu_freq_mhz": 0.0,
    "cpu_count": 0,
    "ram_total_mb": 0.0,
    "ram_used_mb": 0.0,
    "ram_pct": 0.0,
    "proc_rss_mb": 0.0,
    "proc_vms_mb": 0.0,
    "proc_cpu_pct": 0.0,
    "proc_threads": 0,
    "gpu_name": "",
    "gpu_vram_total_mb": 0.0,
    "gpu_vram_used_mb": 0.0,
    "gpu_util_pct": -1.0,
    "gpu_temp_c": -1.0,
    "torch_alloc_mb": 0.0,
    "torch_reserved_mb": 0.0,
    "nn_params": 0,
    "nn_size_mb": 0.0,
    "ollama": [],
    "ollama_total_mb": 0.0,
    "updated": 0.0,
}

viz = {
    "frame": None, "sal": None, "probs": [0.0] * 8, "mouse": (0.0, 0.0),
    "net_view": False, "mode": "human", "intent": 0, "frames": 0,
    "status": "Starting...", "say": "",
    "training": False, "train_step": 0, "train_total": 0, "train_loss": 0.0,
    "train_history": [], "train_label": "",
    "window_ok": True, "paused": False,
    "viz_x": VIZ_X, "viz_y": VIZ_Y,
    "vision": "", "vision_age": 0.0,
    "llm_decision": "", "llm_reason": "", "llm_thought": "",
    "llm_plan": "", "llm_reasoning": "", "llm_decision_age": 0.0,
    "llm_reasoning_age": 0.0,
    "memory_count": 0, "last_memory": "", "last_memory_age": 0.0,
    "thought": "", "thought_age": 0.0,
    "chat_sent": "", "chat_sent_age": 0.0,
    "small_decision": "", "small_decision_age": 0.0,
    "brain": {"has_activations": False, "conv_maps": [], "fc1": None, "fc2": None},
    "recording_count": 0,
    "device_name": device_name,
    "amd_gfx": _AMD_GFX or "",
}
worker_dbg = {"frames_logged": 0}

action_window = deque(maxlen=ACTION_HISTORY_LEN)
vision_history = deque(maxlen=VISION_HISTORY_LEN)
event_log = deque(maxlen=EVENT_HISTORY_LEN)
decision_log = deque(maxlen=DECISION_HISTORY_LEN)
light_history = deque(maxlen=20)
raw_mouse_hist = deque(maxlen=DRIFT_WINDOW)

memories = deque(maxlen=MEMORY_LIMIT)
last_memory_tick = [time.time()]
last_thought_tick = [time.time()]
next_think_time = [time.time() + 20.0]
last_chat_tick = [0.0]
pending_chat = [None]

intent_start_time = [time.time()]

recording_files = []
total_frames_saved = 0


def _scan_recordings():
    global total_frames_saved
    recording_files.clear()
    total_frames_saved = 0
    for f in sorted(glob.glob("recording_*.npz")):
        try:
            with np.load(f) as d:
                n = int(d["frames"].shape[0])
            recording_files.append(f)
            total_frames_saved += n
        except Exception as e:
            print(f"Skipped {f}: {e}")
    viz["recording_count"] = len(recording_files)


def log_event(text):
    event_log.append((time.time(), text))


def load_memories():
    try:
        with open(MEMORY_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        items = data.get("memories", []) if isinstance(data, dict) else data
        for item in items:
            if isinstance(item, dict):
                t = float(item.get("t", time.time()))
                txt = str(item.get("text", ""))[:200].strip()
            else:
                t, txt = time.time(), str(item)[:200].strip()
            if txt:
                memories.append({"t": t, "text": txt})
        if memories:
            print(f"Loaded {len(memories)} memories")
    except FileNotFoundError:
        pass
    except Exception as e:
        print(f"  (could not load memories: {e})")


def save_memories():
    try:
        with open(MEMORY_FILE, "w", encoding="utf-8") as f:
            json.dump({"memories": list(memories)}, f, indent=1)
    except Exception as e:
        print(f"  (save memories failed: {e})")


def _memory_exists(text):
    low = text.lower().strip()
    if not low:
        return True
    for m in memories:
        ml = m["text"].lower().strip()
        if ml == low:
            return True
        if len(low) >= 8 and (low in ml or ml in low):
            return True
        if _similar(low, ml, threshold=0.6):
            return True
    for x in recent_lines:
        xl = x.lower().strip()
        if xl == low:
            return True
        if _similar(low, xl, threshold=0.6):
            return True
    return False


def add_memory(text, source="truman"):
    text = " ".join(str(text).split())[:200].strip()
    text = fix_name(text)
    if not text:
        return
    if _memory_exists(text):
        return
    memories.append({"t": time.time(), "text": text, "src": source})
    viz["memory_count"] = len(memories)
    viz["last_memory"] = text
    viz["last_memory_age"] = 0.0
    last_memory_tick[0] = time.time()
    tag = "remembers" if source == "truman" else f"notes ({source})"
    print(f"[memory] {NAME} {tag}: {text}")
    save_memories()


def _memory_score(m, now):
    age_hours = max(0.05, (now - m["t"]) / 3600.0)
    src = m.get("src", "truman")
    base = {
        "truman": 1.0,
        "muse":   0.5,
        "chat":   0.6,
        "event":  0.15,
    }.get(src, 0.5)
    length_bonus = min(0.4, len(m["text"]) / 250.0)
    recency = 1.0 / (1.0 + age_hours * 0.4)
    short_penalty = 0.3 if len(m["text"]) < 15 else 0.0
    return base + length_bonus + recency * 0.5 - short_penalty


def _prune_memories():
    now = time.time()
    n = len(memories)
    if n < MEMORY_LIMIT * 0.75:
        return
    keep_n = max(8, int(MEMORY_LIMIT * MEMORY_PRUNE_KEEP_FRACTION))
    scored = [(_memory_score(m, now), m) for m in memories]
    scored.sort(key=lambda x: x[0], reverse=True)
    kept = [m for _s, m in scored[:keep_n]]
    dropped = n - len(kept)
    if dropped <= 0:
        return
    memories.clear()
    for m in sorted(kept, key=lambda x: x["t"]):
        memories.append(m)
    viz["memory_count"] = len(memories)
    print(f"[memory] pruned {dropped} low-value memories "
          f"({len(memories)}/{MEMORY_LIMIT})")
    save_memories()


class Net(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(3, 32, 5, 2, 2), nn.ReLU(),
            nn.Conv2d(32, 64, 3, 2, 1), nn.ReLU(),
            nn.Conv2d(64, 128, 3, 2, 1), nn.ReLU(),
            nn.Conv2d(128, 128, 3, 2, 1), nn.ReLU(),
            nn.Flatten())
        self.head = nn.Sequential(
            nn.Linear(128 * 4 * 4 + len(INTENTS), 256), nn.ReLU(),
            nn.Linear(256, N_OUT))

    def forward(self, x, intent_idx):
        oh = nn.functional.one_hot(intent_idx, len(INTENTS)).float()
        return self.head(torch.cat([self.conv(x), oh], dim=1))


def to_input(frames_u8):
    return frames_u8.permute(0, 3, 1, 2).float() / 255.0


def _sigmoid(x):
    """Numerically stable sigmoid. Never calls exp() on a large positive
    number, so it cannot overflow even if x is -1e6 or +1e6."""
    x = np.asarray(x, dtype=np.float64)
    out = np.empty_like(x)
    pos = x >= 0
    neg = ~pos
    out[pos] = 1.0 / (1.0 + np.exp(-x[pos]))
    ex = np.exp(x[neg])
    out[neg] = ex / (1.0 + ex)
    return out


def make_targets(labels):
    y = np.array(labels[:, :N_OUT], dtype=np.float32).copy()
    y[:, 6:8] = np.clip(y[:, 6:8] / MOUSE_SCALE, -MOUSE_CLIP, MOUSE_CLIP)
    if y.shape[0] > 1:
        mx, my = float(y[:, 6].mean()), float(y[:, 7].mean())
        if abs(mx) > 0.005 or abs(my) > 0.005:
            print(f"  mouse target bias: dx={mx:+.4f} dy={my:+.4f} -> removing")
        y[:, 6] -= mx
        y[:, 7] -= my
    return torch.from_numpy(y)


def loss_fn(out, y):
    bce = nn.functional.binary_cross_entropy_with_logits
    return bce(out[:, BINARY_IDX], y[:, BINARY_IDX]) + \
        nn.functional.mse_loss(out[:, 6:8], y[:, 6:8])


model = Net().to(device)
trained = False
try:
    model.load_state_dict(torch.load("model.pt", map_location=device))
    trained = True
    print("Loaded model.pt")
except FileNotFoundError:
    print("No model.pt yet.")
except Exception:
    print("Old model.pt doesn't match - starting fresh.")
model.eval()

brain_acts = {}


def _register_brain_hooks():
    def mk(name):
        def hook(module, inp, out):
            brain_acts[name] = out.detach()
        return hook
    for i, name in enumerate(["conv1", "conv1r", "conv2", "conv2r",
                              "conv3", "conv3r", "conv4", "conv4r"]):
        model.conv[i].register_forward_hook(mk(name))
    model.conv[8].register_forward_hook(mk("flatten"))
    model.head[0].register_forward_hook(mk("fc1"))
    model.head[1].register_forward_hook(mk("fc1r"))
    model.head[2].register_forward_hook(mk("fc2"))


_register_brain_hooks()


def _snapshot_brain(acts):
    try:
        snap = {"has_activations": True, "conv_maps": [], "fc1": None, "fc2": None}
        for name in ["conv1r", "conv2r", "conv3r", "conv4r"]:
            t = acts.get(name)
            if t is not None and t.dim() == 4:
                m = t[0].abs().mean(0).detach().cpu().numpy().copy()
                snap["conv_maps"].append((name.rstrip("r"), m))
        fc1 = acts.get("fc1r")
        if fc1 is not None:
            snap["fc1"] = fc1[0].detach().cpu().numpy().copy()
        fc2 = acts.get("fc2")
        if fc2 is not None:
            snap["fc2"] = fc2[0].detach().cpu().numpy().copy()
        return snap
    except Exception:
        return {"has_activations": False, "conv_maps": [], "fc1": None, "fc2": None}


_scan_recordings()
if recording_files:
    print(f"Found {len(recording_files)} recording file(s) "
          f"({total_frames_saved} frames) on disk")

buf_f, buf_l = [], []
load_memories()
viz["memory_count"] = len(memories)
if memories:
    viz["last_memory"] = memories[-1]["text"]

lock = threading.Lock()
held = set()
buttons = {"left": False, "right": False}
acc = [0, 0]
last_pos = [None]
mode = ["human"]
stop = [False]
toggle = [False]
retrain = [False]
pause_toggle = [False]
paused = [False]
cur_intent = [0]
ai_down = set()
game_center = [None]
live_intent = [0]


def key_name(key):
    if getattr(key, "char", None):
        return key.char.lower()
    if key == keyboard.Key.space:
        return "space"
    if key in (keyboard.Key.shift, keyboard.Key.shift_l, keyboard.Key.shift_r):
        return "shift"
    return str(key)


def on_press(key):
    if key == QUIT_KEY:
        stop[0] = True
        return
    if ui["prompt_active"]:
        return
    if key == TOGGLE_KEY:
        toggle[0] = True
    elif key == RETRAIN_KEY:
        retrain[0] = True
    elif key == PAUSE_KEY:
        pause_toggle[0] = True
    elif key in INTENT_KEYS:
        if mode[0] == "human" and not paused[0]:
            with lock:
                cur_intent[0] = INTENT_KEYS[key]
            print(f"   (labeling as: {INTENTS[INTENT_KEYS[key]]})")
    else:
        with lock:
            held.add(key_name(key))


def on_release(key):
    with lock:
        held.discard(key_name(key))


def on_move(x, y):
    with lock:
        if paused[0] or mode[0] != "human" or ui["prompt_active"]:
            last_pos[0] = (x, y)
            return
        if last_pos[0] is not None:
            px, py = last_pos[0]
            dx, dy = x - px, y - py
            c = game_center[0]
            warp = False
            if c is not None:
                cx, cy = c
                warp = (abs(x - cx) < 8 and abs(y - cy) < 8 and
                        (abs(px - cx) > 24 or abs(py - cy) > 24))
            if (not warp and abs(dx) < MAX_JUMP and abs(dy) < MAX_JUMP and
                    (abs(dx) >= MOUSE_DEADZONE or abs(dy) >= MOUSE_DEADZONE)):
                acc[0] += dx
                acc[1] += dy
        last_pos[0] = (x, y)


def on_click(x, y, button, pressed):
    with lock:
        if button == mouse.Button.left:
            buttons["left"] = pressed
        elif button == mouse.Button.right:
            buttons["right"] = pressed


mouse.Listener(on_move=on_move, on_click=on_click).start()
keyboard.Listener(on_press=on_press, on_release=on_release).start()

last_say = [0.0]


def _describe_light():
    if not light_history:
        return ""
    a = sum(light_history) / len(light_history)
    if a < 40: return "very dark"
    if a < 90: return "dim"
    if a < 160: return "moderately lit"
    return "bright daylight"


def _summarize_actions():
    if not action_window:
        return "standing still"
    n = len(action_window)
    avg = {k: sum(h[k] for h in action_window) / n for k in
           ["w", "a", "s", "d", "space", "shift", "clickL", "clickR"]}
    adx = sum(h["dx"] for h in action_window) / n
    ady = sum(h["dy"] for h in action_window) / n
    parts = []
    if avg["w"] > 0.4: parts.append("walking forward")
    if avg["s"] > 0.3: parts.append("backing up")
    if avg["a"] > 0.3: parts.append("strafing left")
    if avg["d"] > 0.3: parts.append("strafing right")
    if avg["space"] > 0.25: parts.append("jumping")
    if avg["shift"] > 0.3: parts.append("sneaking")
    if adx < -3: parts.append("turning left")
    if adx > 3: parts.append("turning right")
    if ady < -3: parts.append("looking up")
    if ady > 3: parts.append("looking down")
    if avg["clickL"] > 0.3: parts.append("clicking a lot")
    if avg["clickR"] > 0.2: parts.append("right-clicking")
    return ", ".join(parts) if parts else "standing mostly still"


def _fmt_ages(items, now):
    lines = []
    for t, txt in items:
        age = int(now - t)
        if age < 1: lines.append(f"- just now: {txt}")
        elif age < 60: lines.append(f"- {age}s ago: {txt}")
        else: lines.append(f"- {age // 60}m ago: {txt}")
    return lines


def _age_str(s):
    s = int(s)
    if s < 60: return f"{s}s ago"
    if s < 3600: return f"{s // 60}m ago"
    if s < 86400: return f"{s // 3600}h ago"
    return f"{s // 86400}d ago"


def _current_situation_snapshot():
    intent = live_intent[0] if mode[0] == "ai" else cur_intent[0]
    activity = ACTIVITY.get(intent, "wandering around")
    seen = vision_describe.last_text[0] or ""
    light = _describe_light() or ""
    ev = ""
    if event_log:
        t_ev, txt = list(event_log)[-1]
        if time.time() - t_ev < 45:
            ev = txt
    return {"intent": intent, "activity": activity, "seen": seen,
            "light": light, "event": ev}


def llm_speak(intent, stuck, source="intent"):
    if not LLM_AVAILABLE:
        return random.choice(STOCK[intent])
    activity = ACTIVITY[intent]
    if stuck:
        mood = "mildly put out, not upset"
        situation = "You just bumped into something and had to turn away."
    elif source == "intent_start":
        mood = "settling into a new thing to do"
        situation = f"You have just decided to spend some time {activity}."
    else:
        mood = "calm and content"
        situation = f"You are {activity}."
    seen = vision_describe.last_text[0] or ""
    seen_clause = ""
    if seen and not seen.startswith("("):
        seen_clause = f" You can see: {seen}."
    plan = viz.get("llm_plan") or ""
    plan_clause = f" You are working on: {plan}." if plan else ""

    def build():
        return (
            f"{PERSONA}\n\n"
            f"{situation}{seen_clause}{plan_clause}\n"
            f"Your mood right now: {mood}.\n"
            f"{_avoid_clause()}"
            f"Say one short thing out loud - about two to twelve words. Plain, "
            f"unforced, first person. Not a greeting, not a question, not an "
            f"explanation. Just a passing remark as you get on with it.\n"
            f"Write only the words.\n"
        )

    line = _generate_line(build, max_words=14, temp=0.95, min_words=2)
    if not line:
        line = random.choice(STOCK[intent])
    _remember_line(line)
    return line


def announce(intent, stuck=False, source="intent"):
    if time.time() - last_say[0] < 10:
        return
    last_say[0] = time.time()

    def work():
        line = llm_speak(intent, stuck, source)
        print(f"[{NAME}] {line}")
        viz["say"] = f"{NAME}: {line}"
    threading.Thread(target=work, daemon=True).start()


def think_random():
    try:
        use_mem = bool(memories) and random.random() < THINK_MEMORY_CHANCE
        snap = _current_situation_snapshot()
        activity = snap["activity"]
        seen = snap["seen"]
        light = snap["light"]
        if use_mem:
            m = random.choice(list(memories))
            seed = f'A memory surfaces: "{m["text"]}"'
        elif seen and not seen.startswith("("):
            seed = f"You are {activity}, and you can see: {seen}"
        else:
            seed = f"You are {activity}."
        if not LLM_AVAILABLE:
            line = random.choice(STOCK_MUSINGS)
        else:
            light_clause = f"The light is {light}." if light else ""
            plan = viz.get("llm_plan") or ""
            plan_clause = f"You were working on: {plan}." if plan else ""

            def build():
                return (
                    f"{PERSONA}\n\n"
                    f"{seed}\n{light_clause} {plan_clause}\n".strip() + "\n\n"
                    f"{_avoid_clause()}"
                    f"Have a quiet thought to yourself. Two to fourteen words. "
                    f"Plain, unhurried, first person. Not a question, not a "
                    f"greeting, not an announcement. Just a passing thought.\n"
                    f"Write only the thought.\n"
                )

            line = _generate_line(build, max_words=THINK_MAX_WORDS,
                                  temp=0.95, min_words=2)
            if not line:
                line = random.choice(STOCK_MUSINGS)
        line = _truncate_words(line, THINK_MAX_WORDS + 2)
        tag = "muses on a memory" if use_mem else "muses"
        print(f"[{NAME} {tag}] {line}")
        viz["thought"] = line
        viz["thought_age"] = 0.0
        last_thought_tick[0] = time.time()
        _remember_line(line)
        if use_mem and random.random() < 0.15 and line:
            if not _memory_exists(line):
                add_memory(line, source="muse")
        if mode[0] == "ai" and random.random() < live_settings["chat_chance"]:
            threading.Thread(target=chat_generate, daemon=True).start()
    except Exception as e:
        print(f"  (musing failed: {e})")


def _truncate_words(text, max_words):
    words = text.split()
    if len(words) <= max_words:
        return text.strip()
    return " ".join(words[:max_words]).rstrip(",;:") + "."


def chat_generate():
    try:
        snap = _current_situation_snapshot()
        intent = snap["intent"]
        activity = snap["activity"]
        seen = snap["seen"]
        light = snap["light"]
        event = snap["event"]
        chat_words = int(live_settings["chat_max_words"])
        if not LLM_AVAILABLE:
            pool = STOCK_CHAT_BY_ACTIVITY.get(intent, STOCK_CHAT_GENERIC)
            cands = [c for c in pool if c not in recent_chats]
            line = random.choice(cands) if cands else random.choice(pool)
        else:
            bits = [f"You are {activity}."]
            if seen and not seen.startswith("("):
                bits.append(f"You can see: {seen}.")
            if light:
                bits.append(f"The light is {light}.")
            if event:
                bits.append(f"Just happened: {event}.")
            plan = viz.get("llm_plan") or ""
            if plan:
                bits.append(f"You are working on: {plan}.")

            def build():
                return (
                    f"{PERSONA}\n\n" + " ".join(bits) + "\n\n" +
                    _avoid_clause() +
                    f"You are typing one short line into the world chat as you "
                    f"go. Two to {chat_words} words. Plain, unforced, first "
                    f"person. Not a greeting, not a question. Just a passing "
                    f"remark to nobody in particular.\n"
                    f"Write only the words.\n"
                )

            line = _generate_line(build, max_words=chat_words,
                                  temp=1.0, min_words=2)
            if not line:
                pool = STOCK_CHAT_BY_ACTIVITY.get(intent, STOCK_CHAT_GENERIC)
                line = random.choice(pool)
        line = _clean_line(line)
        line = _truncate_words(line, chat_words)
        if not line:
            pool = STOCK_CHAT_BY_ACTIVITY.get(intent, STOCK_CHAT_GENERIC)
            line = random.choice(pool)
        _remember_line(line)
        pending_chat[0] = line
    except Exception as e:
        print(f"  (chat gen failed: {e})")


def type_in_chat(text):
    clean = "".join(c for c in text if 32 <= ord(c) < 127)[:CHAT_MAX_LEN].strip()
    clean = fix_name(clean)
    if len(clean) < 2:
        return

    def tap(key, hold=0.06):
        pydirectinput.keyDown(key)
        time.sleep(hold)
        pydirectinput.keyUp(key)

    try:
        release_all()
        time.sleep(0.25)
        pydirectinput.press(CHAT_KEY, presses=1)
        time.sleep(0.40)
        for ch in clean:
            if ch.isupper():
                pydirectinput.keyDown("shift")
                time.sleep(0.02)
                pydirectinput.keyDown(ch.lower())
                time.sleep(0.04)
                pydirectinput.keyUp(ch.lower())
                pydirectinput.keyUp("shift")
            else:
                tap(ch, hold=0.04)
            time.sleep(0.03)
        time.sleep(0.30)
        pydirectinput.press("enter", presses=1)
        time.sleep(0.25)
        print(f"[{NAME} says in chat] {clean}")
        viz["chat_sent"] = clean
        viz["chat_sent_age"] = 0.0
        last_chat_tick[0] = time.time()
        recent_chats.append(clean.lower())
        add_memory(clean, source="chat")
    except Exception as e:
        print(f"  (chat failed: {e})")


# ---------------- decision-making ----------------
def _build_decision_context(current_intent, stuck):
    now = time.time()
    lines = [f"YOU ARE: {ACTIVITY[current_intent]} "
             f"(started {int(now - intent_start_time[0])}s ago)",
             f"YOUR BODY: {_summarize_actions()}"]
    plan = viz.get("llm_plan") or ""
    if plan:
        lines.append(f"YOUR CURRENT PLAN: {plan}")
    lt = _describe_light()
    if lt:
        lines.append(f"THE LIGHT: {lt}")
    if vision_history:
        lines.append(f"WHAT YOU SAW JUST NOW: {vision_history[-1][1]}")
    if event_log:
        lines.append("RECENT EVENTS:")
        lines.extend(_fmt_ages(list(event_log)[-3:], now))
    if reasoning_history:
        last_t, last_r = reasoning_history[-1]
        age = int(now - last_t)
        lines.append(f"YOUR OWN LAST TRAIN OF THOUGHT ({age}s ago):")
        for key, label in [("see", "you saw"), ("why", "your reason"),
                           ("else", "alternatives you considered"),
                           ("better", "your judgment"),
                           ("next", "you were going to")]:
            v = last_r.get(key)
            if v:
                lines.append(f"- {label}: {v}")
    if decision_log:
        lines.append("YOUR RECENT DECISIONS:")
        for t, it, reason in list(decision_log)[-2:]:
            age = int(now - t)
            lines.append(f"- {age}s ago: {INTENTS[it]}" +
                         (f" - {reason}" if reason else ""))
    if recent_lines:
        lines.append("THINGS YOU SAID RECENTLY (do not repeat these):")
        for x in list(recent_lines)[-2:]:
            lines.append(f"- {x}")
    if memories:
        recent = list(memories)[-MEMORY_IN_PROMPT:]
        lines.append(f"THINGS YOU REMEMBER ({len(memories)}/{MEMORY_LIMIT}):")
        for m in recent:
            lines.append(f"- ({_age_str(now - m['t'])}) {m['text']}")
    if stuck:
        lines.append("NOTE: you just bumped into something and got stuck.")
    return "\n".join(lines)


def _decision_prompt(current_intent, stuck):
    ctx = _build_decision_context(current_intent, stuck)
    return (
        f"{DECISION_PERSONA}\n\n---\n{ctx}\n---\n\n"
        f"Decide what to do next.\n"
        f"First answer these five questions to yourself, one short line each:\n\n"
        f"WHAT I SEE: what is in front of me right now\n"
        f"WHY THIS NOW: why am I doing what I'm doing - is that reason still good?\n"
        f"WHAT ELSE: one or two other things I could be doing instead\n"
        f"WHICH IS BETTER: which one makes more sense now, and why\n"
        f"NEXT STEP: the first concrete thing I would do if I picked it\n\n"
        f"Then commit to a choice, in exactly this format and nothing after it:\n\n"
        f"INTENT: explore | mine | build\n"
        f"REASON: one plain sentence, first person, the honest why\n"
        f"PLAN: what I intend to accomplish over the next minute or so, or blank\n"
        f"THOUGHT: one short first-person thought, under fifteen words\n"
        f"REMEMBER: one small thing worth remembering later, or blank\n"
    )


def _decision_prompt_minimal(current_intent, stuck):
    ctx = _build_decision_context(current_intent, stuck)
    return (
        f"{DECISION_PERSONA}\n\n"
        f"Current situation:\n{ctx}\n\n"
        f"Pick one of: explore, mine, build.\n"
        f"Reply with these four lines and nothing else. "
        f"Do not use bold or markdown. No asterisks.\n"
        f"INTENT: <explore or mine or build>\n"
        f"REASON: <one short first-person sentence about why>\n"
        f"PLAN: <short plan or the word blank>\n"
        f"THOUGHT: <one short first-person thought>\n"
    )


def _decision_prompt_tiny(current_intent, stuck):
    ctx = _build_decision_context(current_intent, stuck)
    return (
        f"{DECISION_PERSONA}\n\n"
        f"{ctx}\n\n"
        f"Reply with exactly one word and nothing else, "
        f"no punctuation, no asterisks:\n"
        f"explore\n"
        f"mine\n"
        f"build\n"
        f"Your answer:"
    )


def _parse_decision(text):
    reasoning_block, fields_block = _split_reasoning_and_fields(text)
    reasoning = _parse_reasoning(reasoning_block)
    intent, reason, plan, thought, memory = None, "", "", "", ""
    for raw_line in fields_block.split("\n"):
        line = raw_line.strip()
        line = re.sub(r"^[*_#>\-•\s]+", "", line).rstrip("*_ ")
        low = line.lower()
        if low.startswith("intent:"):
            val = line.split(":", 1)[1].strip().strip("*_ ").lower()
            for i, name in enumerate(INTENTS):
                if name in val:
                    intent = i
                    break
        elif low.startswith("reason:"):
            reason = line.split(":", 1)[1].strip().strip("*_ ")[:220]
        elif low.startswith("plan:"):
            plan = line.split(":", 1)[1].strip().strip("*_ ")[:200]
        elif low.startswith("thought:"):
            thought = line.split(":", 1)[1].strip().strip("*_ ")[:200]
        elif low.startswith("remember:"):
            memory = line.split(":", 1)[1].strip().strip("*_ ")[:200]

    if intent is None:
        low = text.lower()
        bp = 10**9
        for i, name in enumerate(INTENTS):
            pos = low.find(name)
            if pos != -1 and pos < bp:
                intent, bp = i, pos

    if _is_field_label(reason):
        reason = ""
    if _is_field_label(plan):
        plan = ""
    if _is_field_label(thought):
        thought = ""
    if _is_field_label(memory):
        memory = ""

    if not reason and reasoning.get("why"):
        reason = reasoning["why"]

    reason = _clean_line(reason)
    plan = _clean_line(plan)
    thought = _clean_line(thought)
    memory = _clean_line(memory)
    if thought and not _line_is_usable(thought, 2, 20):
        thought = ""
    if plan and not _line_is_usable(plan, 2, 20):
        plan = ""
    return intent, reason, plan, thought, memory, reasoning


def _parse_tiny(text):
    if not text:
        return None
    low = text.strip().lower()
    low = re.sub(r"[^a-z]", "", low)
    for i, name in enumerate(INTENTS):
        if name in low:
            return i
    return None


def llm_decide_intent(current_intent, stuck, _):
    if not LLM_AVAILABLE:
        return None, "", "", "", "", None

    verbose = llm_decide_intent.session_count[0] < 3
    llm_decide_intent.session_count[0] += 1

    use_deep = bool(live_settings.get("deep_reasoning", False))
    prompt = _decision_prompt(current_intent, stuck) if use_deep \
        else _decision_prompt_minimal(current_intent, stuck)
    num_pred = 240 if use_deep else 140
    raw = _ask_llm(prompt, num_predict=num_pred, temp=0.7, top_p=0.9,
                   timeout=LLM_DECISION_TIMEOUT,
                   stops=["\nUSER:"])
    now = time.time()

    if verbose and raw:
        preview = raw.replace("\n", " / ")[:300]
        print(f"  [decision raw] {preview!r}")

    if not raw:
        if verbose or now - llm_decide_intent.last_empty_time[0] > 20:
            llm_decide_intent.last_empty_time[0] = now
            print("  [decision empty] LLM returned nothing "
                  "(timeout, truncation, or connection issue)")
    else:
        result = _parse_decision(raw)
        if result[0] is not None:
            return result

        if verbose or now - llm_decide_intent.last_unparsed_time[0] > 20:
            llm_decide_intent.last_unparsed_time[0] = now
            preview = raw.replace("\n", " / ")[:260]
            print(f"  [decision unparsed] {preview!r}")

        if use_deep:
            alt_prompt = _decision_prompt_minimal(current_intent, stuck)
            alt_pred = 140
        else:
            alt_prompt = _decision_prompt(current_intent, stuck)
            alt_pred = 240
        raw2 = _ask_llm(alt_prompt, num_predict=alt_pred, temp=0.6, top_p=0.9,
                        timeout=LLM_DECISION_TIMEOUT,
                        stops=["\nUSER:"])
        if raw2:
            if verbose:
                preview = raw2.replace("\n", " / ")[:260]
                print(f"  [decision raw (alt)] {preview!r}")
            result2 = _parse_decision(raw2)
            if result2[0] is not None:
                if verbose or now - llm_decide_intent.last_recovered_time[0] > 20:
                    llm_decide_intent.last_recovered_time[0] = now
                    print("  [decision recovered] alternate prompt parsed OK")
                return result2

    tiny = _decision_prompt_tiny(current_intent, stuck)
    raw3 = _ask_llm(tiny, num_predict=8, temp=0.2, top_p=0.85,
                    timeout=20.0,
                    stops=["\n"])
    if raw3:
        print(f"  [decision tiny] {raw3!r}")
        idx = _parse_tiny(raw3)
        if idx is not None:
            if verbose or now - llm_decide_intent.last_tiny_time[0] > 20:
                llm_decide_intent.last_tiny_time[0] = now
                print("  [decision recovered] tiny prompt parsed OK")
            return idx, "", "", "", "", None

    if now - llm_decide_intent.last_failed_time[0] > 60:
        llm_decide_intent.last_failed_time[0] = now
        print("  [decision FAILED] all three prompts could not be parsed - "
              "falling back to heuristic")
    return None, "", "", "", "", None
llm_decide_intent.last_unparsed_time = [0.0]
llm_decide_intent.last_empty_time = [0.0]
llm_decide_intent.last_recovered_time = [0.0]
llm_decide_intent.last_tiny_time = [0.0]
llm_decide_intent.last_failed_time = [0.0]
llm_decide_intent.session_count = [0]


# ---------------- vision ----------------
def _grab_vision_image():
    with mss.MSS() as sct:
        if game_hwnd is not None:
            rect = get_client_rect_screen(game_hwnd)
            if rect is None:
                return None
            gx, gy, gw, gh = rect
            shot = sct.grab({"left": gx, "top": gy, "width": gw, "height": gh})
        else:
            shot = sct.grab(sct.monitors[1])
    img = Image.frombytes("RGB", shot.size, shot.bgra, "raw", "BGRX")
    img = img.resize((VISION_IMAGE_SIZE, VISION_IMAGE_SIZE), Image.BILINEAR)
    buf = io.BytesIO()
    img.save(buf, format="JPEG", quality=85)
    return base64.b64encode(buf.getvalue()).decode("ascii")


def _ask_vision_model(b64, prompt, timeout=60):
    body = json.dumps({"model": LLM_VISION_MODEL, "prompt": prompt,
                       "images": [b64], "stream": False,
                       "options": {"num_predict": 48, "temperature": 0.3,
                                   "top_p": 0.9, "stop": ["\n"]}}).encode()
    req = urllib.request.Request(OLLAMA_URL + "/api/generate", body,
                                 {"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        obj = json.loads(r.read())
    return (obj.get("response") or "").strip()


VISION_PROMPT = ("Describe what you see in Minecraft in one short sentence. "
                 "Use only Minecraft words: blocks, mobs, biomes, caves, "
                 "water, ores, trees. Never mention anything not in Minecraft.")
VISION_PROMPT_FALLBACK = "Describe what you see in this Minecraft image in one short sentence."
VISION_BANNED = ("game", "gamer", "player", "computer", "screen", "pixel",
                 "monitor", "keyboard", "mouse", "internet", "photo",
                 "photograph", "video", "real life", "real world", "virtual",
                 "simulation", "minecraft is", "bounding", "detected",
                 "coordinates", "the image shows",
                 "in the image", "this image", "in this picture",
                 "the picture shows", "i can see")

_VISION_PREFIXES = (
    "i can see ", "i see ", "the image shows ", "this image shows ",
    "the picture shows ", "this picture shows ", "in the image, ",
    "in this image, ", "in the picture, ", "in this picture, ",
    "the scene shows ", "this scene shows ", "it looks like ",
    "looks like ", "there is ", "there are ",
)


def _clean_vision(raw):
    if not raw:
        return ""
    raw = raw.strip().strip('" ').split("\n")[0].strip()
    low = raw.lower()
    changed = True
    while changed:
        changed = False
        for p in _VISION_PREFIXES:
            if low.startswith(p):
                raw = raw[len(p):].lstrip()
                low = raw.lower()
                changed = True
                break
    for b in VISION_BANNED:
        if b in low:
            return ""
    if len(raw) < 6 or len(raw) > 200:
        return ""
    if sum(c.isdigit() for c in raw) > 8:
        return ""
    if raw.count("[") + raw.count("]") + raw.count("{") + raw.count("}") >= 2:
        return ""
    return raw


def vision_describe():
    if not VISION_AVAILABLE:
        return
    try:
        b64 = _grab_vision_image()
        if b64 is None:
            return
        try:
            raw = _ask_vision_model(b64, VISION_PROMPT)
        except Exception as e:
            msg = f"{type(e).__name__}: {str(e)[:100]}"
            if msg != vision_describe.last_err[0]:
                vision_describe.last_err[0] = msg
                print(f"  (vision call failed: {msg})")
            raw = ""
        cleaned = _clean_vision(raw)
        if not cleaned:
            try:
                raw2 = _ask_vision_model(b64, VISION_PROMPT_FALLBACK)
                cleaned = _clean_vision(raw2)
                if not raw:
                    raw = raw2
            except Exception:
                cleaned = ""
        if not cleaned:
            now = time.time()
            if raw and (raw != vision_describe.last_raw[0]
                        or now - vision_describe.last_raw_time[0] > 30):
                vision_describe.last_raw[0] = raw[:180]
                vision_describe.last_raw_time[0] = now
                print(f"  [vision raw, rejected] {raw[:160]!r}")
            vision_describe.last_text[0] = ""
            viz["vision"] = ""
            viz["vision_age"] = 0.0
            return
        desc = cleaned if cleaned.endswith(('.', '!', '?')) else (cleaned + ".")
        text = f"{NAME} sees: {desc}"[:180]
        print(f"[vision] {text}")
        viz["vision"] = text
        viz["vision_age"] = 0.0
        vision_describe.last_text[0] = cleaned[:140]
        vision_history.append((time.time(), cleaned[:140]))
    except Exception as e:
        msg = f"{type(e).__name__}: {str(e)[:100]}"
        if msg != vision_describe.last_err[0]:
            vision_describe.last_err[0] = msg
            print(f"  (vision failed: {msg})")
vision_describe.last_err = [None]
vision_describe.last_text = [""]
vision_describe.last_raw = [""]
vision_describe.last_raw_time = [0.0]


def send_prompt(text):
    ui["prompt_last"] = text
    ui["prompt_response"] = ""
    ui["prompt_pending"] = True
    if not LLM_AVAILABLE:
        ui["prompt_response"] = "(no LLM available)"
        ui["prompt_pending"] = False
        return

    def work():
        try:
            snap = _current_situation_snapshot()
            bits = [f"You are {snap['activity']}."]
            if snap['seen'] and not snap['seen'].startswith('('):
                bits.append(f"You can see: {snap['seen']}.")
            if snap['light']:
                bits.append(f"The light is {snap['light']}.")
            plan = viz.get("llm_plan") or ""
            if plan:
                bits.append(f"You were working on: {plan}.")
            convo = ""
            if conversation_history:
                convo = ("Earlier, a voice said things and you answered:\n")
                for u, t in list(conversation_history)[-3:]:
                    convo += f"  Voice: {u}\n  You: {t}\n"
                convo += "\n"

            def build():
                return (
                    f"{PERSONA}\n\n" + " ".join(bits) + "\n\n" + convo +
                    f"A voice from nowhere says to you: \"{text}\"\n\n"
                    f"Answer out loud, in character, first person. One short "
                    f"sentence, under twenty words. You don't know where the "
                    f"voice comes from and it doesn't frighten you. You can be "
                    f"curious, easygoing, wry, or quiet - whatever the words "
                    f"actually bring up. Do not perform happiness. You can "
                    f"address the voice as \"you\" if it feels right.\n"
                    f"Write only what you say.\n"
                )

            line = _generate_line(build, max_words=25, temp=0.95, min_words=2,
                                  reject_questions=False)
            if not line:
                line = "..."
            ui["prompt_response"] = line[:220]
            print(f"[{NAME} replies] {line}")
            conversation_history.append((text[:160], line[:160]))
            low = text.lower()
            if any(w in low for w in ("mine", "dig", "mining", "digging")):
                pending_actions.append(("intent", "mine"))
            elif any(w in low for w in ("build", "place", "building", "placing")):
                pending_actions.append(("intent", "build"))
            elif any(w in low for w in ("explore", "walk", "exploring",
                                        "walking", "wander")):
                pending_actions.append(("intent", "explore"))
        except Exception as e:
            ui["prompt_response"] = f"(error: {str(e)[:80]})"
        finally:
            ui["prompt_pending"] = False

    threading.Thread(target=work, daemon=True).start()


# ---------------- AI control ----------------
def release_all():
    for k in list(ai_down):
        try:
            pydirectinput.keyUp(k)
        except Exception:
            pass
    ai_down.clear()


def smooth_move(dx, dy, duration, pieces=4):
    if dx == 0 and dy == 0:
        return
    px = py = 0
    for i in range(1, pieces + 1):
        tx = int(round(dx * i / pieces))
        ty = int(round(dy * i / pieces))
        sx, sy = tx - px, ty - py
        if sx or sy:
            pydirectinput.moveRel(sx, sy, relative=True)
        px, py = tx, ty
        time.sleep(duration / pieces)


def _apply_drift_correction(dx, dy):
    raw_mouse_hist.append((dx, dy))
    if len(raw_mouse_hist) < DRIFT_MIN_SAMPLES:
        return dx, dy
    n = len(raw_mouse_hist)
    ax = sum(h[0] for h in raw_mouse_hist) / n
    ay = sum(h[1] for h in raw_mouse_hist) / n
    if abs(ay) <= DRIFT_INTENTIONAL_CUTOFF:
        corr = int(round(ay))
        corr = max(-DRIFT_MAX_CORRECT, min(DRIFT_MAX_CORRECT, corr))
        dy -= corr
    if abs(ax) <= DRIFT_INTENTIONAL_CUTOFF:
        corr = int(round(ax))
        corr = max(-DRIFT_MAX_CORRECT, min(DRIFT_MAX_CORRECT, corr))
        dx -= corr
    dx = int(max(-AI_MOUSE_MAX_PER_TICK, min(AI_MOUSE_MAX_PER_TICK, dx)))
    dy = int(max(-AI_MOUSE_MAX_PER_TICK, min(AI_MOUSE_MAX_PER_TICK, dy)))
    return dx, dy


def ai_step(frame, intent):
    fa = np.array(frame[None], copy=True, order="C")
    x = to_input(torch.from_numpy(fa)).to(device).detach().requires_grad_(True)
    it = torch.tensor([intent], device=device)
    out_t = model(x, it)

    sal = None
    try:
        model.zero_grad()
        torch.sigmoid(out_t[0, BINARY_IDX]).sum().backward()
        if x.grad is not None:
            sal_arr = x.grad.abs().max(dim=1)[0][0].cpu().numpy()
            sal = (sal_arr / (sal_arr.max() + 1e-8)) ** 0.5
    except Exception as e:
        if not ai_step._backward_warned:
            ai_step._backward_warned = True
            print(f"  (saliency backward unavailable on {device_name}: "
                  f"{type(e).__name__}: {str(e)[:80]})")

    viz["brain"] = _snapshot_brain(brain_acts)
    out = out_t.detach().squeeze(0).cpu().numpy().copy()
    bias = INTENT_BIAS.get(intent, INTENT_BIAS[0])
    out[0] += bias["w"]; out[1] += bias["a"]; out[2] += bias["s"]; out[3] += bias["d"]
    out[4] += bias["space"]; out[5] += bias["shift"]
    out[8] += bias["clickL"]; out[9] += bias["clickR"]
    out[6] += bias["dx"] * MOUSE_CLIP; out[7] += bias["dy"] * MOUSE_CLIP
    p = _sigmoid(out)

    rdx = int(np.clip(out[6], -MOUSE_CLIP, MOUSE_CLIP) * MOUSE_SCALE)
    rdy = int(np.clip(out[7], -MOUSE_CLIP, MOUSE_CLIP) * MOUSE_SCALE)
    mdl_dx = 0 if abs(rdx) < AI_MOUSE_DEADZONE else int(np.clip(rdx, -AI_MOUSE_MAX_PER_TICK, AI_MOUSE_MAX_PER_TICK))
    mdl_dy = 0 if abs(rdy) < AI_MOUSE_DEADZONE else int(np.clip(rdy, -AI_MOUSE_MAX_PER_TICK, AI_MOUSE_MAX_PER_TICK))
    mdl_dx, mdl_dy = _apply_drift_correction(mdl_dx, mdl_dy)

    now = time.time()
    st = _scan_state
    if st["last"] is None:
        st["last"] = now
    dt = max(0.0, min(0.25, now - st["last"]))
    st["last"] = now
    st["t"] += dt
    phase = 2.0 * math.pi * st["t"] / SCAN_PERIOD
    y_phase = 2.0 * math.pi * st["t"] / (SCAN_PERIOD / SCAN_Y_RATIO)
    x_target = SCAN_AMPLITUDE_X * math.sin(phase)
    y_target = SCAN_AMPLITUDE_Y * math.sin(y_phase)
    scan_dx = x_target - st["x_prev"]
    scan_dy = y_target - st["y_prev"]
    st["x_prev"] = x_target
    st["y_prev"] = y_target

    if abs(mdl_dx) < SCAN_DOMINANCE:
        dx = mdl_dx + int(round(scan_dx))
    else:
        dx = mdl_dx
    if abs(mdl_dy) < SCAN_DOMINANCE:
        dy = mdl_dy + int(round(scan_dy))
    else:
        dy = mdl_dy

    dx = int(max(-AI_MOUSE_MAX_PER_TICK, min(AI_MOUSE_MAX_PER_TICK, dx)))
    dy = int(max(-AI_MOUSE_MAX_PER_TICK, min(AI_MOUSE_MAX_PER_TICK, dy)))

    action_window.append({
        "w": float(p[0]), "a": float(p[1]), "s": float(p[2]), "d": float(p[3]),
        "space": float(p[4]), "shift": float(p[5]),
        "clickL": float(p[8]), "clickR": float(p[9]), "dx": dx, "dy": dy})
    viz["sal"] = sal
    viz["probs"] = [float(v) for v in p[:6]] + [float(p[8]), float(p[9])]
    viz["mouse"] = (max(-1.0, min(1.0, dx / MOUSE_DISPLAY_SCALE)),
                    max(-1.0, min(1.0, dy / MOUSE_DISPLAY_SCALE)))
    viz["net_view"] = True
    if ui["prompt_active"]:
        if ai_down:
            release_all()
        return
    want = {KEYS[i] for i in range(6) if random.random() < p[i]}
    for k in want - ai_down:
        pydirectinput.keyDown(k)
    for k in ai_down - want:
        pydirectinput.keyUp(k)
    ai_down.clear()
    ai_down.update(want)
    if random.random() < p[8]:
        pydirectinput.click()
    if random.random() < p[9]:
        pydirectinput.click(button="right")
    smooth_move(dx, dy, INTERVAL * 0.8)
ai_step._backward_warned = False


def save_buffer():
    global total_frames_saved
    with lock:
        if not buf_f:
            return
        nf = np.stack(buf_f).astype(np.uint8)
        nl = np.array(buf_l, dtype=np.float32)
        buf_f.clear()
        buf_l.clear()
    stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    fname = f"recording_session_{stamp}.npz"
    np.savez_compressed(fname, frames=nf, labels=nl)
    del nf, nl
    recording_files.append(fname)
    try:
        with np.load(fname) as d:
            total_frames_saved += int(d["frames"].shape[0])
    except Exception:
        pass
    viz["recording_count"] = len(recording_files)


def _load_training_data():
    cap = int(live_settings.get("train_max_frames", 8000))
    if not recording_files:
        return None, None
    entries = []
    total_avail = 0
    for fname in list(recording_files):
        try:
            with np.load(fname) as d:
                n = int(d["frames"].shape[0])
            entries.append((fname, n))
            total_avail += n
        except Exception as e:
            print(f"  skip {fname}: {e}")
    if not entries:
        return None, None
    print(f"  loading training data: {total_avail} frames across "
          f"{len(entries)} file(s), cap {cap}")
    load_all = total_avail <= cap
    frac = 1.0 if load_all else cap / float(total_avail)
    plan = []
    total_take = 0
    for fname, n in entries:
        if load_all:
            take = n
        else:
            take = max(1, int(round(n * frac)))
            take = min(take, n)
        plan.append((fname, n, take))
        total_take += take
    if total_take == 0:
        return None, None
    F = np.empty((total_take, 64, 64, 3), dtype=np.uint8)
    L = np.empty((total_take, N_OUT + 1), dtype=np.float32)
    offset = 0
    for fname, n, take in plan:
        try:
            d = np.load(fname)
            frames = d["frames"]
            labels = d["labels"]
        except Exception as e:
            print(f"  skip {fname}: {e}")
            continue
        if labels.shape[1] == N_OUT:
            ext = np.zeros((len(labels), N_OUT + 1), dtype=np.float32)
            ext[:, :N_OUT] = labels
            labels = ext
        if take >= n:
            F[offset:offset + n] = frames
            L[offset:offset + n] = labels[:, :N_OUT + 1]
            offset += n
        else:
            idx = np.sort(np.random.choice(n, size=take, replace=False))
            F[offset:offset + take] = frames[idx]
            L[offset:offset + take] = labels[idx, :N_OUT + 1]
            offset += take
        del frames, labels, d
    if offset < total_take:
        F = F[:offset]
        L = L[:offset]
    print(f"  loaded {len(F)} frames for training")
    return F, L


def train(label="Training"):
    global trained
    with lock:
        buf_stack = None
        buf_lab = None
        if buf_f:
            buf_stack = np.stack(buf_f).astype(np.uint8)
            buf_lab = np.array(buf_l, dtype=np.float32)
            buf_f.clear()
            buf_l.clear()
    F_old, L_old = _load_training_data()
    parts_f, parts_l = [], []
    if buf_stack is not None:
        parts_f += [buf_stack] * 3
        parts_l += [buf_lab] * 3
    if F_old is not None:
        parts_f.append(F_old)
        parts_l.append(L_old)
    if not parts_f:
        print("  no data to train on")
        return
    F = np.concatenate(parts_f)
    L = np.concatenate(parts_l)
    del parts_f, parts_l, F_old, L_old
    X = torch.from_numpy(F)
    I = torch.from_numpy(np.ascontiguousarray(L[:, N_OUT].astype(np.int64)))
    Y = make_targets(L)
    try:
        ic = L[:, N_OUT].astype(int)
        tot = len(ic)
        print("  data coverage:")
        for i, name in enumerate(INTENTS):
            n = int((ic == i).sum())
            print(f"    {name:8s}: {n:5d} frames ({100.0 * n / max(1, tot):.1f}%)")
    except Exception:
        pass
    steps = FINETUNE_STEPS if trained else FIRST_TRAIN_STEPS
    opt = torch.optim.Adam(model.parameters(), lr=3e-4 if trained else 1e-3)
    viz["training"] = True
    viz["train_label"] = label
    viz["train_step"] = 0
    viz["train_total"] = steps
    viz["train_loss"] = 0.0
    viz["train_history"] = []
    viz["status"] = f"{label} 0/{steps}"
    model.train()
    win = []
    last = 0.0
    try:
        for s in range(1, steps + 1):
            b = torch.randint(0, len(X), (64,))
            loss = loss_fn(model(to_input(X[b]).to(device), I[b].to(device)),
                           Y[b].to(device))
            opt.zero_grad(); loss.backward(); opt.step()
            win.append(loss.item())
            if s % 10 == 0 or s == steps:
                last = sum(win) / len(win)
                win.clear()
                viz["train_step"] = s
                viz["train_loss"] = last
                viz["train_history"].append((s, last))
                viz["status"] = f"{label} {s}/{steps}  loss {last:.3f}"
            if s % 100 == 0:
                print(f"  step {s}/{steps}  loss {last:.4f}")
        model.eval()
        torch.save(model.state_dict(), "model.pt")
        trained = True
        print("  saved model.pt")
    finally:
        viz["training"] = False
        viz["train_step"] = steps
        viz["train_loss"] = last
        del X, Y, I, F, L


def _heuristic_next(ci, stuck):
    candidates = [i for i in range(len(INTENTS)) if i != ci]
    if not candidates:
        return 0
    if stuck:
        if 0 in candidates:
            return 0
        return random.choice(candidates)

    score = {i: 0.0 for i in candidates}

    plan = (viz.get("llm_plan") or "").lower()
    if plan:
        for i, name in enumerate(INTENTS):
            if i in score and name in plan:
                score[i] += 1.5

    seen = (vision_describe.last_text[0] or "").lower()
    if seen:
        if any(w in seen for w in ("ore", "cave", "stone", "deep", "rock")):
            if 1 in score:
                score[1] += 0.8
        if any(w in seen for w in ("grass", "sky", "field", "hill",
                                    "tree", "forest", "shore", "beach")):
            if 0 in score:
                score[0] += 0.8
        if any(w in seen for w in ("house", "village", "wall", "roof",
                                    "path", "fence")):
            if 2 in score:
                score[2] += 0.8

    recent = [it for _t, it, _r in list(decision_log)[-3:]]
    for it in recent:
        if it in score:
            score[it] -= 0.6

    score[ci] = score.get(ci, 0.0) - 5.0

    for k in score:
        score[k] += random.uniform(0.0, 0.6)

    best = max(score.items(), key=lambda kv: kv[1])[0]
    return best


def _refresh_perf():
    now = time.time()
    if now - perf["updated"] < 1.0:
        return
    perf["updated"] = now

    if PSUTIL_AVAILABLE:
        try:
            perf["cpu_pct"] = float(psutil.cpu_percent(interval=None))
            perf["cpu_per_core"] = list(
                psutil.cpu_percent(interval=None, percpu=True) or [])
            perf["cpu_count"] = int(psutil.cpu_count(logical=True) or 0)
            try:
                f = psutil.cpu_freq()
                perf["cpu_freq_mhz"] = float(f.current) if f else 0.0
            except Exception:
                perf["cpu_freq_mhz"] = 0.0
            vm = psutil.virtual_memory()
            perf["ram_total_mb"] = vm.total / (1024 ** 2)
            perf["ram_used_mb"] = (vm.total - vm.available) / (1024 ** 2)
            perf["ram_pct"] = float(vm.percent)
            p = psutil.Process(os.getpid())
            try:
                with p.oneshot():
                    mi = p.memory_info()
                    perf["proc_rss_mb"] = mi.rss / (1024 ** 2)
                    perf["proc_vms_mb"] = mi.vms / (1024 ** 2)
                    perf["proc_cpu_pct"] = float(p.cpu_percent(interval=None))
                    perf["proc_threads"] = int(p.num_threads())
            except Exception:
                pass
        except Exception:
            pass

    try:
        if CUDA_AVAILABLE and device_name in ("cuda", "legacy"):
            perf["torch_alloc_mb"] = torch.cuda.memory_allocated() / (1024 ** 2)
            perf["torch_reserved_mb"] = torch.cuda.memory_reserved() / (1024 ** 2)
        else:
            perf["torch_alloc_mb"] = 0.0
            perf["torch_reserved_mb"] = 0.0
    except Exception:
        pass
    try:
        n = sum(p.numel() for p in model.parameters())
        perf["nn_params"] = int(n)
        perf["nn_size_mb"] = n * 4 / (1024 ** 2)
    except Exception:
        pass

    try:
        with urllib.request.urlopen(OLLAMA_URL + "/api/ps", timeout=3) as r:
            data = json.loads(r.read())
        loaded = []
        total = 0.0
        for m in data.get("models", [])[:8]:
            size = (m.get("size") or 0) / (1024 ** 2)
            vram = (m.get("size_vram") or 0) / (1024 ** 2)
            name = m.get("name") or m.get("model") or "?"
            loaded.append({"name": name, "size_mb": size, "vram_mb": vram})
            total += size
        perf["ollama"] = loaded
        perf["ollama_total_mb"] = total
    except Exception:
        perf["ollama"] = []
        perf["ollama_total_mb"] = 0.0

    if CUDA_AVAILABLE:
        try:
            out = subprocess.check_output(
                ["nvidia-smi",
                 "--query-gpu=name,memory.total,memory.used,utilization.gpu,temperature.gpu",
                 "--format=csv,noheader,nounits"],
                timeout=3, stderr=subprocess.DEVNULL).decode("utf-8", "ignore")
            line = out.strip().splitlines()[0]
            parts = [x.strip() for x in line.split(",")]
            if len(parts) >= 5:
                perf["gpu_name"] = parts[0]
                perf["gpu_vram_total_mb"] = float(parts[1])
                perf["gpu_vram_used_mb"] = float(parts[2])
                perf["gpu_util_pct"] = float(parts[3])
                perf["gpu_temp_c"] = float(parts[4])
        except Exception:
            pass
    elif _AMD_GFX:
        perf["gpu_name"] = f"AMD Radeon ({_AMD_GFX})"
    elif DIRECTML_AVAILABLE:
        perf["gpu_name"] = "DirectML device"


def _perf_loop():
    while not stop[0]:
        try:
            _refresh_perf()
        except Exception:
            pass
        time.sleep(1.5)


threading.Thread(target=_perf_loop, daemon=True).start()


def main():
    global game_hwnd, game_title
    global device_name, device

    print()
    print("Click into ClassiCube. You are in control.")
    print("F8=handover F7=retrain F9=pause F10=quit")
    print("Use the visualizer window: prompt box at bottom, tabs at top.")
    viz["status"] = "Looking for the game window..."

    if AUTOPLAY:
        if trained:
            print("Autoplay: starting in 5 seconds...")
            time.sleep(5)
            toggle[0] = True
        else:
            print("Autoplay needs a model.pt.")

    ai_intent = [0]
    intent_until = [0.0]
    still_count = [0]
    prev_frame = [None]
    stuck_escape = {"active": False, "until": 0.0, "keys": set(),
                    "dx_remaining": 0, "cooldown_until": 0.0}
    last_window_check = 0.0
    last_foreground_warn = 0.0
    last_vision = [0.0]
    last_vision_tick = [time.time()]
    last_decision_tick = [time.time()]
    last_reasoning_tick = [time.time()]
    last_prune = [time.time()]
    decision = {"pending": None, "thread": None, "for": None, "asked_for": None}

    def _decide_worker(ci, stuck):
        try:
            idx, reason, plan, thought, memory, reasoning = \
                llm_decide_intent(ci, stuck, "")
            decision["pending"] = (idx, reason, plan, thought, memory, reasoning)
            decision["for"] = (ci, stuck)
        except Exception as e:
            print(f"  (decision worker: {e})")
            decision["pending"] = (None, "", "", "", "", None)
            decision["for"] = (ci, stuck)

    def request_decision(ci, stuck):
        if not live_settings["llm_decides"] or not LLM_AVAILABLE:
            return
        if decision["thread"] is not None and decision["thread"].is_alive():
            return
        # Only ask once per (intent, stuck) pair. Firing the same question
        # repeatedly was the reason the LLM's answer never reached the game:
        # each new request cleared decision["pending"] right after the
        # previous worker had populated it.
        if decision.get("asked_for") == (ci, stuck):
            return
        decision["asked_for"] = (ci, stuck)
        t = threading.Thread(target=_decide_worker, args=(ci, stuck), daemon=True)
        decision["thread"] = t
        t.start()

    def choose_next(ci, stuck):
        pending = decision["pending"]
        thread_dead = not (decision["thread"] and decision["thread"].is_alive())
        # Accept the pending LLM answer as long as:
        #   - a worker has finished
        #   - the answer was requested for the same intent we're still on
        #     (the "stuck" flag flipping is not a reason to throw it away)
        if (pending is not None and thread_dead and
                decision["for"] is not None and decision["for"][0] == ci):
            idx, reason, plan, thought, memory, reasoning = pending
            decision["pending"] = None
            decision["for"] = None
            decision["asked_for"] = None
            if idx is not None:
                return idx, reason, plan, thought, memory, reasoning, "llm"
        # Nothing usable. Clear the ask flag so a fresh request can fire
        # for the new intent, then fall back to the heuristic.
        decision["asked_for"] = None
        nxt = _heuristic_next(ci, stuck)
        return nxt, "", "", "", "", None, "heuristic"

    with mss.MSS() as sct:
        while not stop[0]:
            t0 = time.time()
            if viz["vision"]:
                viz["vision_age"] = time.time() - last_vision_tick[0]
            if viz["llm_decision"]:
                viz["llm_decision_age"] = time.time() - last_decision_tick[0]
            if viz["llm_reasoning"]:
                viz["llm_reasoning_age"] = time.time() - last_reasoning_tick[0]
            if viz["last_memory"]:
                viz["last_memory_age"] = time.time() - last_memory_tick[0]
            if viz["thought"]:
                viz["thought_age"] = time.time() - last_thought_tick[0]
            if viz["chat_sent"]:
                viz["chat_sent_age"] = time.time() - last_chat_tick[0]
            if viz["small_decision"] and small_decide_state["last_time"] > 0:
                viz["small_decision_age"] = time.time() - small_decide_state["last_time"]

            while pending_actions:
                act = pending_actions.popleft()
                if act[0] == "device":
                    new_mode = act[1]
                    if not _device_available(new_mode):
                        print(f"  ({new_mode} not available - ignoring)")
                    else:
                        new_name, new_obj = _resolve_device(new_mode)
                        if new_name == device_name:
                            pass
                        else:
                            try:
                                model.to(new_obj)
                                device_name, device = new_name, new_obj
                                viz["device_name"] = device_name
                                print(f">>> Compute device -> {device_name}")
                                if device_name == "legacy":
                                    backend = ("DirectML" if DIRECTML_AVAILABLE
                                               else "ROCm" if CUDA_AVAILABLE
                                               else "CPU")
                                    print(f"    (legacy path via {backend})")
                                try:
                                    if device_name in ("cuda", "legacy") and CUDA_AVAILABLE:
                                        torch.cuda.empty_cache()
                                except Exception:
                                    pass
                            except Exception as e:
                                print(f"  (device move failed: "
                                      f"{type(e).__name__}: {str(e)[:100]})")
                                live_settings["device_mode"] = "auto"
                                save_settings()
                elif act[0] == "intent" and mode[0] == "ai":
                    name = act[1]
                    if name in INTENTS:
                        ni = INTENTS.index(name)
                        ai_intent[0] = ni
                        live_intent[0] = ni
                        intent_start_time[0] = time.time()
                        intent_until[0] = time.time() + _intent_duration()
                        still_count[0] = 0
                        print(f">>> prompt set intent -> {name}")
                        viz["llm_decision"] = f"prompt: {name}"
                        viz["llm_reason"] = "you asked"
                        viz["llm_thought"] = ""
                        viz["llm_plan"] = ""
                        viz["llm_reasoning"] = ""
                        viz["llm_decision_age"] = 0.0
                        last_decision_tick[0] = time.time()
                        announce(ni, False, source="intent_start")

            if pause_toggle[0]:
                pause_toggle[0] = False
                paused[0] = not paused[0]
                viz["paused"] = paused[0]
                if paused[0]:
                    release_all()
                    print(">>> PAUSED (F9 to resume)")
                    viz["status"] = "PAUSED - press F9 to resume"
                else:
                    print(">>> RESUMED")
                    viz["status"] = ("AI is playing" if mode[0] == "ai"
                                     else "You are in control (recording)")

            if paused[0]:
                release_all()
                time.sleep(0.1)
                continue

            if game_hwnd is None or (time.time() - last_window_check) > 2.0:
                last_window_check = time.time()
                if game_hwnd is None or not user32.IsWindow(game_hwnd):
                    hwnd, title = find_game_window(WINDOW_TITLE)
                    if hwnd is not None:
                        game_hwnd = hwnd
                        game_title = title
                        print(f"Found game window: {title!r}")
                        viz["status"] = "Game window found."
                        if AUTO_FOCUS_GAME:
                            force_game_foreground(game_hwnd)
                    else:
                        if game_hwnd is None:
                            viz["status"] = f"Waiting for {WINDOW_TITLE!r}..."
                        game_hwnd = None

            if game_hwnd is None:
                viz["window_ok"] = False
                time.sleep(0.5)
                continue

            rect = get_client_rect_screen(game_hwnd)
            if rect is None:
                viz["window_ok"] = False
                viz["status"] = "Game window minimized."
                time.sleep(0.3)
                continue

            gx, gy, gw, gh = rect
            game_center[0] = (gx + gw // 2, gy + gh // 2)
            viz["window_ok"] = True

            if not is_foreground(game_hwnd):
                if ui["prompt_active"]:
                    release_all()
                    time.sleep(0.1)
                    continue
                if AUTO_FOCUS_GAME and mode[0] == "ai":
                    if time.time() - last_foreground_warn > AUTO_REFOCUS_SEC:
                        last_foreground_warn = time.time()
                        force_game_foreground(game_hwnd)
                        time.sleep(0.15)
                        if not is_foreground(game_hwnd):
                            print("(game window not focused - paused)")
                            viz["status"] = "Click into the game to resume."
                            release_all()
                            time.sleep(0.2)
                            continue
                    else:
                        time.sleep(0.1)
                        continue
                else:
                    if time.time() - last_foreground_warn > 5:
                        last_foreground_warn = time.time()
                        print("(game window not focused - paused)")
                    viz["status"] = "Click into the game to resume."
                    release_all()
                    time.sleep(0.2)
                    continue

            if VISION_AVAILABLE and time.time() - last_vision[0] > live_settings["vision_interval"]:
                last_vision[0] = time.time()
                last_vision_tick[0] = time.time()
                threading.Thread(target=vision_describe, daemon=True).start()

            if time.time() >= next_think_time[0]:
                next_think_time[0] = time.time() + random.uniform(
                    live_settings["think_min"], live_settings["think_max"])
                threading.Thread(target=think_random, daemon=True).start()

            if time.time() - last_prune[0] > MEMORY_PRUNE_INTERVAL:
                last_prune[0] = time.time()
                try:
                    _prune_memories()
                except Exception as e:
                    print(f"  (prune failed: {e})")

            if pending_chat[0] is not None:
                text = pending_chat[0]
                pending_chat[0] = None
                if mode[0] == "ai" and not paused[0] and not ui["prompt_active"]:
                    type_in_chat(text)
                else:
                    pending_chat[0] = None

            with lock:
                frames_now = len(buf_f) + total_frames_saved
            viz["frames"] = frames_now

            if mode[0] == "human" and len(buf_f) >= AUTOSAVE_EVERY:
                print(f">>> Auto-saving ({len(buf_f)} frames)...")
                save_buffer()

            if retrain[0]:
                retrain[0] = False
                if mode[0] == "human":
                    print(">>> Retraining now...")
                    save_buffer()
                    train(label="Retraining")
                    viz["status"] = "You are in control (recording)"
                continue

            if toggle[0]:
                toggle[0] = False
                if mode[0] == "ai":
                    release_all()
                    with lock:
                        mode[0] = "human"
                        held.clear()
                        acc[0] = acc[1] = 0
                        last_pos[0] = None
                    viz["mode"] = "human"
                    viz["net_view"] = False
                    viz["sal"] = None
                    viz["status"] = "You are in control (recording)"
                    raw_mouse_hist.clear()
                    pending_chat[0] = None
                    print(">>> YOU are in control (recording)")
                else:
                    with lock:
                        new = len(buf_f)
                    total = new + total_frames_saved
                    if not trained and total < MIN_FIRST_FRAMES:
                        print(f">>> Not enough data ({total}/{MIN_FIRST_FRAMES})")
                        continue
                    save_buffer()
                    if (not trained) or new >= RETRAIN_MIN_FRAMES:
                        print(f">>> Training on {new} new frames...")
                        train(label="First training" if not trained else "Fine-tuning")
                    else:
                        print(f">>> Using saved model ({new} new frames)")
                    decision["pending"] = None
                    decision["thread"] = None
                    decision["for"] = None
                    decision["asked_for"] = None
                    stuck_helper["asked"] = False
                    stuck_helper["answer"] = None
                    stuck_helper["for"] = None
                    ai_intent[0] = 0
                    live_intent[0] = 0
                    intent_start_time[0] = time.time()
                    intent_until[0] = time.time() + _intent_duration()
                    still_count[0] = 0
                    prev_frame[0] = None
                    stuck_escape.update({"active": False, "keys": set(),
                                         "dx_remaining": 0, "cooldown_until": 0.0})
                    raw_mouse_hist.clear()
                    action_window.clear()
                    event_log.clear()
                    decision_log.clear()
                    reasoning_history.clear()
                    recent_chats.clear()
                    recent_lines.clear()
                    conversation_history.clear()
                    release_all()
                    if AUTO_FOCUS_GAME:
                        force_game_foreground(game_hwnd)
                    with lock:
                        mode[0] = "ai"
                    viz["mode"] = "ai"
                    viz["status"] = "AI is playing (F8 to take over)"
                    print(f">>> AI is in control")
                    log_event(f"started {INTENTS[0]}")
                    if not memories:
                        add_memory("Woke up feeling fine, the usual.", source="event")
                    next_think_time[0] = time.time() + random.uniform(
                        max(15.0, live_settings["think_min"]),
                        max(25.0, live_settings["think_max"]))
                    announce(0, False, source="intent_start")
                    request_decision(0, False)
                continue

            mon = {"left": gx, "top": gy, "width": gw, "height": gh}
            try:
                shot = sct.grab(mon)
            except Exception as e:
                print("grab failed:", e)
                time.sleep(0.2)
                continue
            img = Image.frombytes("RGB", shot.size, shot.bgra, "raw", "BGRX")
            if VIZ and live_settings["viz_mask"]:
                vx0 = viz.get("viz_x", VIZ_X)
                vy0 = viz.get("viz_y", VIZ_Y)
                vx1, vy1 = vx0 + VIZ_W, vy0 + VIZ_H
                ix0, iy0 = max(vx0, gx), max(vy0, gy)
                ix1, iy1 = min(vx1, gx + gw), min(vy1, gy + gh)
                if ix1 > ix0 and iy1 > iy0:
                    ImageDraw.Draw(img).rectangle(
                        (ix0 - gx, iy0 - gy, ix1 - gx, iy1 - gy), fill=(0, 0, 0))
            frame = np.ascontiguousarray(np.asarray(img.resize((64, 64)), dtype=np.uint8))
            viz["frame"] = frame
            light_history.append(float(frame.mean()))
            if worker_dbg["frames_logged"] < 5:
                print(f"frame #{worker_dbg['frames_logged']+1}: min={frame.min()} max={frame.max()}")
                worker_dbg["frames_logged"] += 1

            if mode[0] == "ai":
                if prev_frame[0] is not None:
                    diff = np.abs(frame.astype(np.int16) - prev_frame[0].astype(np.int16)).mean()
                    still_count[0] = still_count[0] + 1 if diff < STUCK_DIFF else 0
                prev_frame[0] = frame
                stuck = still_count[0] >= STUCK_FRAMES

                # Preemptive small decision request.
                if 6 <= still_count[0] < STUCK_FRAMES:
                    if (live_settings.get("small_decisions", True)
                            and LLM_AVAILABLE
                            and not stuck_helper["asked"]):
                        q, opts = _small_stuck_question(ai_intent[0], still_count[0])
                        _ask_stuck_helper_bg(ai_intent[0], q, opts)
                        stuck_helper["asked"] = True
                        print(f"   (small decision requested: {q[:60]}...)")
                elif still_count[0] < 3:
                    stuck_helper["asked"] = False

                if stuck_escape["active"]:
                    if time.time() >= stuck_escape["until"]:
                        stuck_escape["active"] = False
                        stuck_escape["keys"] = set()
                        release_all()
                    else:
                        for k in stuck_escape["keys"]:
                            if k not in ai_down:
                                pydirectinput.keyDown(k)
                        ai_down.clear()
                        ai_down.update(stuck_escape["keys"])
                        if stuck_escape["dx_remaining"] != 0:
                            step = max(-60, min(60, stuck_escape["dx_remaining"]))
                            pydirectinput.moveRel(step, 0, relative=True)
                            stuck_escape["dx_remaining"] -= step
                        raw_mouse_hist.append((0, 0))
                        still_count[0] = 0
                        prev_frame[0] = frame
                        time.sleep(max(0, t0 - time.time() + INTERVAL))
                        continue

                if stuck and not stuck_escape["active"] and \
                        time.time() > stuck_escape["cooldown_until"]:
                    esc = None
                    if live_settings.get("small_decisions", True):
                        esc = _consume_stuck_helper(ai_intent[0])
                    if esc is None:
                        esc = STUCK_ESCAPE.get(ai_intent[0], STUCK_ESCAPE[0])
                        print(f"   stuck escape ({esc['desc']}) [fallback]")
                    else:
                        print(f"   stuck escape ({esc['desc']}) [small-llm]")
                        viz["small_decision"] = esc.get("choice", "")
                        viz["small_decision_age"] = 0.0
                    stuck_helper["asked"] = False
                    stuck_escape["active"] = True
                    stuck_escape["until"] = time.time() + esc["duration"]
                    stuck_escape["keys"] = set(esc["keys"])
                    stuck_escape["dx_remaining"] = esc["turn_dx"]
                    stuck_escape["cooldown_until"] = time.time() + STUCK_ESCAPE_COOLDOWN
                    log_event("got stuck")
                    add_memory("Caught on a block and had to back off. Fine.", source="event")
                    announce(ai_intent[0], True, source="stuck")
                    release_all()
                    time.sleep(max(0, t0 - time.time() + INTERVAL))
                    continue

                time_to_change = (stuck and time.time() > stuck_escape["cooldown_until"]) \
                    or time.time() > intent_until[0]
                if (not stuck and live_settings["llm_decides"] and
                        time.time() > intent_until[0] - LLM_PREFETCH_SEC and
                        time.time() <= intent_until[0]):
                    request_decision(ai_intent[0], False)

                if time_to_change:
                    ni, reason, plan, thought, memory, reasoning, source = \
                        choose_next(ai_intent[0], stuck)
                    prev_name = INTENTS[ai_intent[0]]
                    ai_intent[0] = ni
                    live_intent[0] = ni
                    intent_start_time[0] = time.time()
                    intent_until[0] = time.time() + _intent_duration()
                    still_count[0] = 0
                    tag = "(stuck) " if stuck else ""
                    src = "[llm]" if source == "llm" else "[heur]"
                    print(f"   intent -> {INTENTS[ai_intent[0]]} {tag}{src}")
                    if reasoning:
                        print("   train of thought:")
                        for key, label in [("see", "I see"),
                                           ("why", "why this now"),
                                           ("else", "what else"),
                                           ("better", "which is better"),
                                           ("next", "next step")]:
                            v = reasoning.get(key)
                            if v:
                                print(f"     {label}: {v}")
                    if reason:
                        print(f"   reason: {reason}")
                    if plan:
                        print(f"   plan:   {plan}")
                    if thought:
                        print(f"   thinks: {thought}")
                    decision_log.append((time.time(), ai_intent[0],
                                         reason or (reasoning or {}).get("better")
                                         or thought))
                    if ai_intent[0] != prev_name:
                        log_event(f"{prev_name} -> {INTENTS[ai_intent[0]]}")
                    if memory:
                        add_memory(memory, source="truman")
                    viz["llm_decision"] = f"{NAME} decided: {INTENTS[ai_intent[0]]}"
                    viz["llm_reason"] = reason or ""
                    viz["llm_thought"] = thought or ""
                    viz["llm_plan"] = plan or ""
                    if reasoning:
                        viz["llm_reasoning"] = reasoning.get("raw") or ""
                        viz["llm_reasoning_age"] = 0.0
                        last_reasoning_tick[0] = time.time()
                        reasoning_history.append((time.time(), reasoning))
                    viz["llm_decision_age"] = 0.0
                    last_decision_tick[0] = time.time()
                    announce(ai_intent[0], stuck, source="intent_start")
                    if stuck:
                        request_decision(ai_intent[0], False)
                viz["intent"] = ai_intent[0]
                ai_step(frame, ai_intent[0])
            else:
                time.sleep(max(0, t0 + INTERVAL - time.time()))
                with lock:
                    row = [1 if k in held else 0 for k in KEYS]
                    row += [acc[0], acc[1], int(buttons["left"]), int(buttons["right"])]
                    row.append(cur_intent[0])
                    acc[0] = acc[1] = 0
                    buf_f.append(frame)
                    buf_l.append(row)
                viz["probs"] = [float(v) for v in row[:6]] + [float(row[8]), float(row[9])]
                viz["mouse"] = (max(-1.0, min(1.0, row[6] / MOUSE_DISPLAY_SCALE)),
                                max(-1.0, min(1.0, row[7] / MOUSE_DISPLAY_SCALE)))
                viz["intent"] = cur_intent[0]

            time.sleep(max(0, t0 - time.time() + INTERVAL))


def worker_main():
    try:
        main()
    except Exception:
        print("\n=== ERROR ===")
        traceback.print_exc()
    finally:
        stop[0] = True
        release_all()
        try:
            save_buffer()
        except Exception as e:
            print(f"  (final save failed: {e})")
        save_memories()
        print("Saved.")


def wrap_text(text, width=60, max_lines=2):
    words = text.split()
    lines, cur = [], ""
    for w in words:
        if len(cur) + len(w) + 1 > width:
            lines.append(cur)
            cur = w
        else:
            cur = (cur + " " + w).strip()
    if cur:
        lines.append(cur)
    return lines[:max_lines]


def run_viz():
    try:
        rl.set_config_flags(rl.FLAG_WINDOW_TOPMOST)
    except Exception:
        pass
    rl.init_window(VIZ_W, VIZ_H, "Truman - AI view")
    rl.set_exit_key(rl.KEY_NULL)
    rl.set_window_position(VIZ_X, VIZ_Y)
    rl.set_target_fps(30)

    RGBA_BYTES = 64 * 64 * 4
    upload_buf = ffi.new("unsigned char[]", b"\x00" * RGBA_BYTES)

    def make_tex():
        im = rl.gen_image_color(64, 64, rl.BLACK)
        try:
            rl.image_format(im, rl.PIXELFORMAT_UNCOMPRESSED_R8G8B8A8)
        except Exception:
            pass
        t = rl.load_texture_from_image(im)
        rl.unload_image(im)
        rl.set_texture_filter(t, rl.TEXTURE_FILTER_POINT)
        return t

    tex_in, tex_sal = make_tex(), make_tex()
    tex_ok = [True]

    def upload(tex, arr):
        if not tex_ok[0] or arr.shape != (64, 64, 3):
            return
        try:
            rgba = np.dstack([arr, np.full((64, 64), 255, np.uint8)])
            rgba = np.ascontiguousarray(rgba, dtype=np.uint8)
            ffi.buffer(upload_buf, RGBA_BYTES)[:] = rgba.tobytes()
            rl.update_texture(tex, upload_buf)
        except Exception as e:
            tex_ok[0] = False
            print("upload fail:", e)

    def draw_tex(tex, x, y, size):
        rl.draw_texture_pro(tex, rl.Rectangle(0, 0, 64, 64),
                            rl.Rectangle(x, y, size, size),
                            rl.Vector2(0, 0), 0.0, rl.WHITE)

    BG = (18, 20, 26)
    PANEL = (28, 31, 40)
    PANEL_HI = (40, 45, 58)
    EDGE = (54, 60, 78)
    TXT = (232, 236, 244)
    DIM = (152, 160, 178)
    FAINT = (104, 112, 130)
    ACC = (96, 150, 255)
    GOOD = (88, 208, 132)
    WARN = (255, 200, 90)
    BAD = (240, 96, 96)
    PURP = (190, 150, 255)
    ORNG = (255, 150, 70)
    TEAL = (120, 210, 200)
    INTENT_COLS = [ACC, ORNG, PURP]
    TABS = ["Live", "Mind", "Brain", "Perf", "Settings"]
    bar_names = ["W", "A", "S", "D", "Space", "Shift", "Click L", "Click R"]

    PROMPT_X, PROMPT_Y, PROMPT_W, PROMPT_H = 20, VIZ_H - 90, 440, 34
    SEND_X, SEND_W = PROMPT_X + PROMPT_W + 10, 70

    spec_by_key = {sp[2]: sp for sp in SETTINGS_SPEC}

    inp = {"x": 0.0, "y": 0.0, "pressed": False, "down": False,
           "released": False, "wheel": 0.0, "hot": False}

    def K(t, a=255):
        return rl.Color(int(t[0]), int(t[1]), int(t[2]), int(a))

    def lighten(t, d):
        return tuple(max(0, min(255, c + d)) for c in t)

    def hover(x, y, w, h):
        return x <= inp["x"] <= x + w and y <= inp["y"] <= y + h

    def tw(s, size):
        return rl.measure_text(str(s), int(size))

    def text(s, x, y, size=15, col=TXT, a=255):
        rl.draw_text(str(s), int(x), int(y), int(size), K(col, a))

    def fit(s, size, maxw):
        s = str(s)
        if tw(s, size) <= maxw:
            return s
        s = s[:max(1, int(maxw // 3))]
        while len(s) > 1 and tw(s + "...", size) > maxw:
            s = s[:-1]
        return s + "..."

    def rrect(x, y, w, h, col, rad=6, a=255):
        r = max(0.0, min(1.0, 2.0 * rad / max(1.0, min(w, h))))
        rl.draw_rectangle_rounded(rl.Rectangle(x, y, w, h), r, 8, K(col, a))

    def panel(x, y, w, h):
        rrect(x - 1, y - 1, w + 2, h + 2, EDGE, 7)
        rrect(x, y, w, h, PANEL, 6)

    def bar(x, y, w, h, frac, col):
        rrect(x, y, w, h, (50, 54, 66), h / 2.0)
        frac = max(0.0, min(1.0, frac))
        if frac > 0.0:
            rrect(x, y, max(float(h), w * frac), h, col, h / 2.0)

    def chip(x, y, label, col, size=12):
        w = tw(label, size) + 16
        rrect(x, y, w, size + 8, col, 4, 55)
        text(label, x + 8, y + 4, size, col)
        return w

    def button(x, y, w, h, label, base=PANEL_HI, fg=TXT, size=14):
        hov = hover(x, y, w, h)
        bg = base
        if hov:
            inp["hot"] = True
            bg = lighten(base, -10 if inp["down"] else 14)
        rrect(x, y, w, h, bg, 5)
        text(label, x + (w - tw(label, size)) / 2.0, y + (h - size) / 2.0, size, fg)
        return hov and inp["pressed"]

    def toast(msg):
        ui["toast"] = msg
        ui["toast_until"] = time.time() + 2.2

    def set_setting(key, v):
        sp = spec_by_key[key]
        mn, mx_, dec = sp[4], sp[5], sp[6]
        v = max(mn, min(mx_, v))
        v = int(round(v)) if dec == 0 else round(float(v), dec)
        live_settings[key] = v
        for lo, hi in (("think_min", "think_max"), ("intent_min", "intent_max")):
            if key == lo and live_settings[lo] > live_settings[hi]:
                live_settings[hi] = live_settings[lo]
            elif key == hi and live_settings[hi] < live_settings[lo]:
                live_settings[lo] = live_settings[hi]

    def fmt_value(key):
        dec = spec_by_key[key][6]
        v = live_settings[key]
        return str(int(v)) if dec == 0 else f"{v:.{dec}f}"

    def slider(x, y, w, key):
        sp = spec_by_key[key]
        step, mn, mx_ = sp[3], sp[4], sp[5]
        hov = hover(x - 8, y, w + 16, 24)
        if hov:
            inp["hot"] = True
            if inp["pressed"]:
                ui["drag"] = key
        dragging = ui["drag"] == key
        if dragging and inp["down"]:
            f = max(0.0, min(1.0, (inp["x"] - x) / float(w)))
            set_setting(key, mn + round((f * (mx_ - mn)) / step) * step)
        v = live_settings[key]
        frac = max(0.0, min(1.0, (v - mn) / float(mx_ - mn)))
        cy = y + 12
        rrect(x, cy - 3, w, 6, (54, 60, 78), 3)
        rrect(x, cy - 3, max(6.0, w * frac), 6, ACC, 3)
        rl.draw_circle(int(x + w * frac), int(cy), 9 if (hov or dragging) else 7, K(TXT))

    def switch(x, y, on):
        rrect(x, y, 44, 22, GOOD if on else (70, 76, 92), 11)
        rl.draw_circle(int(x + (33 if on else 11)), int(y + 11), 8, K((255, 255, 255)))

    def choice_row(x, y, w, key, choices):
        n = len(choices)
        gap = 3
        bw = max(34, (w - (n - 1) * gap) // n)
        cur = live_settings[key]
        for i, ch in enumerate(choices):
            bx = x + i * (bw + gap)
            avail = _device_available(ch) if key == "device_mode" else True
            active = (cur == ch)
            hov = hover(bx, y, bw, 24)
            if hov and avail:
                inp["hot"] = True
            if not avail:
                bg = (36, 40, 50)
                fg = (90, 96, 112)
            elif active:
                bg = ACC if ch != "legacy" else PURP
                fg = (255, 255, 255)
            elif hov:
                bg = lighten(PANEL_HI, 12)
                fg = TXT
            else:
                bg = PANEL_HI
                fg = DIM
            rrect(bx, y, bw, 24, bg, 5)
            text(ch, bx + (bw - tw(ch, 11)) / 2.0, y + 6, 11, fg)
            if hov and avail and inp["pressed"]:
                live_settings[key] = ch
                save_settings()
                if key == "device_mode":
                    pending_actions.append(("device", ch))

    def draw_header(s):
        x = 20
        for i, name in enumerate(TABS):
            w = tw(name, 16) + 22
            active = ui["tab"] == i
            hov = hover(x, 12, w, 30)
            if hov:
                inp["hot"] = True
            bg = ACC if active else (lighten(PANEL_HI, 12) if hov else PANEL_HI)
            rrect(x, 12, w, 30, bg, 6)
            text(name, x + 11, 20, 16, (255, 255, 255) if active else DIM)
            if hov and inp["pressed"]:
                ui["tab"] = i
                ui["drag"] = None
            x += w + 6
        items = []
        if s.get("paused"):
            items.append(("PAUSED", WARN))
        elif s["mode"] == "ai":
            items.append(("AI", GOOD))
        else:
            items.append(("REC", ACC))
        items.append(("OK", GOOD) if s.get("window_ok", True) else ("NO WIN", BAD))
        dn = s.get("device_name", "cpu")
        if dn == "legacy":
            items.append(("LEGACY", PURP))
        elif dn == "dml":
            items.append(("DML", PURP))
        elif dn == "cuda":
            items.append(("CUDA", PURP))
        rx = 540
        for label, col in reversed(items):
            w = tw(label, 11) + 14
            rx -= w
            chip(rx, 20, label, col, size=11)
            rx -= 5

    def feed_row(y, tag, col, msg, age=None, lines=1):
        chip(32, y, tag, col)
        maxw = 380
        if age is not None:
            a = _age_str(age)
            text(a, 540 - 12 - tw(a, 12), y + 4, 12, FAINT)
        if not msg:
            text("-", 96, y + 2, 14, FAINT)
            return
        if lines == 1:
            text(fit(msg, 14, maxw), 96, y + 2, 14, TXT)
        else:
            for k, ln in enumerate(wrap_text(msg, 52, lines)):
                text(fit(ln, 14, maxw), 96, y + 2 + k * 18, 14, TXT)

    def draw_live(s):
        frame, sal = s["frame"], s["sal"]
        ai = s["mode"] == "ai"
        paused_now = bool(s.get("paused", False))

        panel(20, 56, 520, 282)
        text("WHAT THE AI SEES  (64x64)", 32, 62, 12, FAINT)
        text("WHERE IT IS LOOKING", 284, 62, 12, FAINT)
        draw_tex(tex_in, 32, 80, 244)
        draw_tex(tex_sal, 284, 80, 244)
        rl.draw_rectangle_lines(32, 80, 244, 244, K(ACC))
        rl.draw_rectangle_lines(284, 80, 244, 244, K(EDGE))
        if frame is None:
            msg = "waiting for the game window..."
            text(msg, 32 + (244 - tw(msg, 14)) / 2.0, 196, 14, DIM)
        elif not s.get("window_ok", True):
            msg = "game window not found"
            text(msg, 32 + (244 - tw(msg, 14)) / 2.0, 196, 14, BAD)
        if sal is None:
            msg = "(shown while the AI plays)"
            text(msg, 284 + (244 - tw(msg, 14)) / 2.0, 196, 14, DIM)
        if not ai and not paused_now:
            rl.draw_circle(46, 94, 5, K(BAD))
            text("REC", 56, 88, 12, BAD)

        panel(20, 346, 520, 126)
        text("AI WANTS TO PRESS" if s["net_view"] else "YOU ARE PRESSING", 32, 354, 12, FAINT)
        probs = s.get("probs", [0.0] * 8)
        for i, name in enumerate(bar_names):
            col_, row_ = i // 4, i % 4
            bx = 32 + col_ * 258
            by = 374 + row_ * 22
            v = max(0.0, min(1.0, probs[i] if i < len(probs) else 0.0))
            text(name, bx, by, 14, TXT if v > 0.5 else DIM)
            bar(bx + 62, by + 2, 140, 12, v, GOOD if ai else ACC)
            text(f"{int(v * 100):>3d}%", bx + 208, by + 1, 12, DIM)

        panel(20, 480, 128, 128)
        text("MOUSE", 32, 488, 12, FAINT)
        px, py = 36, 506
        rrect(px, py, 96, 96, (22, 24, 31), 6)
        cx, cy = px + 48, py + 48
        rl.draw_line(px + 4, cy, px + 92, cy, K(EDGE))
        rl.draw_line(cx, py + 4, cx, py + 92, K(EDGE))
        mdx, mdy = s["mouse"]
        rl.draw_line_ex(rl.Vector2(cx, cy), rl.Vector2(cx + mdx * 44, cy + mdy * 44),
                        3, K(ORNG))
        rl.draw_circle(cx, cy, 3, K(TXT))

        panel(156, 480, 384, 128)
        text("CONTROL", 168, 490, 12, FAINT)
        if paused_now:
            chip(244, 486, "PAUSED", WARN)
        elif ai:
            chip(244, 486, "AI", GOOD)
        else:
            chip(244, 486, "YOU", ACC)
        text("INTENT", 168, 522, 12, FAINT)
        ix = 244
        for i, name in enumerate(INTENTS):
            w = tw(name, 13) + 22
            active = s["intent"] == i
            hov = hover(ix, 514, w, 26)
            if hov:
                inp["hot"] = True
            col = INTENT_COLS[i]
            rrect(ix, 514, w, 26, col, 6, 255 if active else (95 if hov else 45))
            text(name, ix + 11, 520, 13, BG if active else col)
            if hov and inp["pressed"]:
                if ai:
                    pending_actions.append(("intent", name))
                elif not paused_now:
                    with lock:
                        cur_intent[0] = i
            ix += w + 8
        text("FRAMES", 168, 552, 12, FAINT)
        text(f"{s['frames']}  ({s.get('recording_count', 0)} files)  "
             f"mem {s.get('memory_count', 0)}/{MEMORY_LIMIT}",
             244, 550, 14, TXT)
        text("STATUS", 168, 578, 12, FAINT)
        lat = _ask_llm_last_latency[0]
        if lat > 0:
            lstr = f"LLM: {lat:.1f}s"
            lcol = GOOD if lat < 5 else (WARN if lat < 20 else BAD)
            text(lstr, 540 - 12 - tw(lstr, 12), 578, 12, lcol)
            text(fit(s["status"], 14, 240), 244, 576, 14, WARN)
        else:
            text(fit(s["status"], 14, 284), 244, 576, 14, WARN)

        # small decision indicator
        panel(20, 616, 520, 22)
        sd = s.get("small_decision", "")
        if sd:
            a = _age_str(s.get("small_decision_age", 0.0))
            text(f"small: {sd}", 32, 621, 12, PURP)
            text(a, 540 - 12 - tw(a, 11), 622, 11, FAINT)
            hits = small_decide_state["hits"]
            misses = small_decide_state["misses"]
            tot = hits + misses
            if tot > 0:
                text(f"hits {hits}/{tot}", 400, 622, 11, DIM)
        else:
            text("small: (idle)", 32, 621, 12, FAINT)

        panel(20, 646, 520, 142)
        text("TRUMAN", 32, 654, 12, FAINT)
        say = s.get("say", "")
        if say.startswith(NAME + ": "):
            say = say[len(NAME) + 2:]
        feed_row(674, "SAYS", WARN, say, lines=2)
        vis = s.get("vision", "")
        pre = f"{NAME} sees: "
        if vis.startswith(pre):
            vis = vis[len(pre):]
        feed_row(718, "SEES", ACC, vis, s.get("vision_age") if vis else None)
        feed_row(742, "MUSES", PURP, s.get("thought", ""),
                 s.get("thought_age") if s.get("thought") else None)
        feed_row(766, "CHAT", GOOD, s.get("chat_sent", ""),
                 s.get("chat_sent_age") if s.get("chat_sent") else None)

        panel(20, 796, 520, 86)
        text("TRAINING", 32, 804, 12, FAINT)
        tr = bool(s.get("training", False))
        total = max(1, int(s.get("train_total", 0) or 0))
        step = int(s.get("train_step", 0) or 0)
        hist = list(s.get("train_history", []))
        bar(32, 824, 496, 10, (step / float(total)) if tr else 0.0, WARN)
        if tr:
            text(f"{s.get('train_label', 'Training')}   {step}/{total}", 32, 842, 14, TXT)
            text(f"loss {s.get('train_loss', 0.0):.3f}", 32, 862, 13, DIM)
        else:
            text("Idle", 32, 842, 14, TXT)
            if hist:
                text(f"last loss {hist[-1][1]:.3f}", 32, 862, 13, DIM)
            else:
                text("no training yet (F7 while recording)", 32, 862, 13, DIM)
        if len(hist) >= 2:
            vals = [h[1] for h in hist][-60:]
            lo, hi = min(vals), max(vals)
            span = max(1e-6, hi - lo)
            sx0, sy0, sw, sh = 280, 840, 248, 34
            pts = [(sx0 + sw * i / float(len(vals) - 1), sy0 + sh - sh * (v - lo) / span)
                   for i, v in enumerate(vals)]
            for a, b in zip(pts, pts[1:]):
                rl.draw_line_ex(rl.Vector2(a[0], a[1]), rl.Vector2(b[0], b[1]), 2, K(GOOD))

    mem_cache = {"items": [], "count": -1}

    def draw_mind(s):
        now = time.time()

        panel(20, 56, 520, 122)
        text("LATEST DECISION", 32, 64, 12, FAINT)
        dec = s.get("llm_decision", "")
        text(fit(dec or "no decision yet", 17, 400), 32, 82, 17, TXT if dec else FAINT)
        if dec:
            a = _age_str(s.get("llm_decision_age", 0.0))
            text(a, 540 - 12 - tw(a, 12), 86, 12, FAINT)
        chip(32, 108, "WHY", ACC)
        for k, ln in enumerate(wrap_text(s.get("llm_reason", "") or "-", 54, 1)):
            text(fit(ln, 14, 420), 96, 110, 14, TXT)
        chip(32, 130, "PLAN", GOOD)
        for k, ln in enumerate(wrap_text(s.get("llm_plan", "") or "-", 54, 1)):
            text(fit(ln, 14, 420), 96, 132, 14, TXT)
        chip(32, 152, "THINKS", PURP)
        for k, ln in enumerate(wrap_text(s.get("llm_thought", "") or "-", 54, 1)):
            text(fit(ln, 14, 420), 96, 154, 14, TXT)

        panel(20, 186, 520, 268)
        text("TRAIN OF THOUGHT", 32, 194, 12, FAINT)
        if s.get("llm_reasoning"):
            a = _age_str(s.get("llm_reasoning_age", 0.0))
            text(a, 540 - 12 - tw(a, 12), 194, 12, FAINT)
        reasoning = s.get("llm_reasoning") or ""
        parsed = _parse_reasoning(reasoning) if reasoning else None
        rows = [
            ("WHAT I SEE", "see", ACC),
            ("WHY THIS NOW", "why", WARN),
            ("WHAT ELSE", "else", TEAL),
            ("WHICH IS BETTER", "better", PURP),
            ("NEXT STEP", "next", GOOD),
        ]
        if not reasoning:
            msg = "(turn on Deep reasoning in Settings to see this)"
            text(msg, 32 + (496 - tw(msg, 14)) / 2.0, 300, 14, DIM)
        else:
            y = 214
            for label, key, col in rows:
                chip(32, y, label, col)
                val = (parsed or {}).get(key, "") or "-"
                lines = wrap_text(val, 56, 2)
                for k, ln in enumerate(lines):
                    text(fit(ln, 14, 390), 148, y + 3 + k * 16, 14,
                         TXT if val != "-" else FAINT)
                y += 46

        panel(20, 462, 520, 100)
        text("RECENT EVENTS", 32, 470, 12, FAINT)
        try:
            evs = list(event_log)[-4:][::-1]
        except Exception:
            evs = []
        if not evs:
            text("nothing yet", 32, 492, 14, FAINT)
        for i, (t, msg) in enumerate(evs):
            text(_age_str(now - t), 32, 492 + i * 18, 13, FAINT)
            text(fit(msg, 14, 400), 110, 491 + i * 18, 14, TXT)

        panel(20, 570, 520, 282)
        if mem_cache["count"] != len(memories):
            mem_cache["items"] = list(memories)[::-1]
            mem_cache["count"] = len(memories)
        items = mem_cache["items"]
        text(f"MEMORIES  {len(items)}/{MEMORY_LIMIT}", 32, 578, 12, FAINT)
        hint = "scroll to see more"
        text(hint, 540 - 12 - tw(hint, 12), 578, 12, FAINT)
        ax, ay, aw, ah = 28, 598, 500, 246
        eh = 58
        total = len(items) * eh
        max_scroll = max(0, total - ah)
        if hover(20, 570, 520, 282):
            ui["mind_scroll"] -= inp["wheel"] * 48
        ui["mind_scroll"] = max(0.0, min(float(max_scroll), ui["mind_scroll"]))
        if not items:
            text("No memories yet. They appear once the AI starts playing.",
                 32, 610, 14, FAINT)
        rl.begin_scissor_mode(ax, ay, aw, ah)
        for i, m in enumerate(items):
            y = ay + i * eh - ui["mind_scroll"]
            if y > ay + ah or y + eh < ay:
                continue
            rrect(ax, y, aw - 12, eh - 6, PANEL_HI, 6)
            src = m.get("src", "memory")
            text(f"{_age_str(now - m['t'])}  -  {src}", ax + 10, y + 5, 12, FAINT)
            for k, ln in enumerate(wrap_text(m["text"], 62, 2)):
                text(fit(ln, 14, aw - 40), ax + 10, y + 20 + k * 16, 14, TXT)
        rl.end_scissor_mode()
        if max_scroll > 0:
            th = max(24.0, ah * ah / float(total))
            ty = ay + (ah - th) * (ui["mind_scroll"] / float(max_scroll))
            rrect(532, ay, 4, ah, (50, 54, 66), 2)
            rrect(532, ty, 4, th, DIM, 2)

    def draw_brain(s):
        brain = s.get("brain") or {}
        has = bool(brain.get("has_activations", False))
        conv_maps = brain.get("conv_maps") or []
        fc1 = brain.get("fc1")
        fc2 = brain.get("fc2")

        y = 56
        panel(20, y, 520, 158)
        text("NETWORK ARCHITECTURE", 32, y + 8, 12, FAINT)
        text("input 64x64x3", 32, y + 30, 12, DIM)

        conv_info = [("conv1", "32x32x32"), ("conv2", "16x16x64"),
                     ("conv3", "8x8x128"), ("conv4", "4x4x128")]
        bx, by = 32, y + 46
        for i, (name, shape) in enumerate(conv_info):
            w, h = 110, 42
            rrect(bx, by, w, h, PANEL_HI, 6)
            text(name, bx + 8, by + 4, 14, ACC)
            text(shape, bx + 8, by + 22, 12, DIM)
            bx += w
            if i < len(conv_info) - 1:
                rl.draw_line_ex(rl.Vector2(bx + 2, by + h / 2),
                                rl.Vector2(bx + 8, by + h / 2), 2, K(EDGE))
                bx += 10

        text("flatten 2048 + one-hot intent 3 = 2051", 32, y + 100, 13, DIM)
        bx, by = 32, y + 118
        for name, shape in [("fc1", "256"), ("fc2", "10")]:
            w = 160
            rrect(bx, by, w, 30, PANEL_HI, 6)
            text(f"{name}  {shape}", bx + 8, by + 6, 13, ACC)
            bx += w + 12
            if name == "fc1":
                rl.draw_line_ex(rl.Vector2(bx - 14, by + 15),
                                rl.Vector2(bx - 6, by + 15), 2, K(EDGE))

        y = 224
        panel(20, y, 520, 168)
        text("CONV ACTIVATIONS  (mean over channels, last frame)", 32, y + 8, 12, FAINT)
        if not has or not conv_maps:
            msg = "(run the AI to see activations)"
            text(msg, 32 + (496 - tw(msg, 14)) / 2.0, y + 78, 14, DIM)
        else:
            bx, cy, cell = 32, y + 30, 76
            for name, m in conv_maps[:4]:
                H, W = m.shape
                mmax = float(m.max())
                if mmax < 1e-6:
                    mmax = 1.0
                cw, chh = cell / W, cell / H
                for row in range(H):
                    for col in range(W):
                        v = max(0.0, min(1.0, float(m[row, col]) / mmax)) ** 0.6
                        r = int(20 + 225 * v)
                        g = int(60 + 120 * v)
                        b = int(110 + 100 * (1 - v))
                        rl.draw_rectangle(int(bx + col * cw), int(cy + row * chh),
                                          int(cw + 1), int(chh + 1), K((r, g, b)))
                rl.draw_rectangle_lines(int(bx), int(cy), cell, cell, K(EDGE))
                text(name, bx, cy + cell + 2, 12, DIM)
                text(f"{H}x{W}", bx, cy + cell + 16, 11, FAINT)
                bx += cell + 24

        y = 402
        panel(20, y, 520, 178)
        text("FC1 ACTIVATIONS  (256 neurons)", 32, y + 8, 12, FAINT)
        if not has or fc1 is None:
            msg = "(no data)"
            text(msg, 32 + (496 - tw(msg, 14)) / 2.0, y + 80, 14, DIM)
        else:
            n = len(fc1)
            cols, cw, chh = 32, 15, 8
            mmax = float(np.abs(fc1).max()) or 1.0
            for i in range(min(n, 256)):
                col, row = i % cols, i // cols
                v = max(0.0, min(1.0, float(abs(fc1[i])) / mmax))
                x0, y0 = 32 + col * cw, y + 30 + row * chh
                r = int(30 + 200 * v)
                g = int(60 + 100 * (1 - v))
                b = int(100 + 155 * v)
                rl.draw_rectangle(x0, y0, cw - 1, chh - 1, K((r, g, b)))
            text(f"range {float(fc1.min()):+.2f} .. {float(fc1.max()):+.2f}",
                 360, y + 8, 11, DIM)

        y = 590
        panel(20, y, 520, 238)
        text("OUTPUT LAYER  (10 raw actions)", 32, y + 8, 12, FAINT)
        if not has or fc2 is None:
            msg = "(no data)"
            text(msg, 32 + (496 - tw(msg, 14)) / 2.0, y + 110, 14, DIM)
        else:
            names = ["W", "A", "S", "D", "Space", "Shift",
                     "dX", "dY", "Click L", "Click R"]
            for i in range(min(10, len(fc2))):
                ry = y + 30 + i * 20
                text(names[i], 32, ry + 2, 13, TXT)
                raw = float(fc2[i])
                if i in (6, 7):
                    disp = float(np.tanh(raw))
                    frac = (disp + 1.0) / 2.0
                    bar(110, ry + 3, 320, 12, frac, ORNG)
                    text(f"{disp:+.2f}", 440, ry + 1, 12, ORNG)
                else:
                    frac = float(_sigmoid(np.float64(raw)))
                    col = GOOD if frac > 0.5 else ACC
                    bar(110, ry + 3, 320, 12, frac, col)
                    text(f"{frac:.2f}", 440, ry + 1, 12, DIM)

    def draw_perf(s):
        p = perf
        y = 56

        panel(20, y, 520, 216)
        text("SYSTEM", 32, y + 8, 12, FAINT)

        cy = y + 32
        text("CPU", 32, cy + 2, 15, TXT)
        cp = max(0.0, min(100.0, p["cpu_pct"]))
        bar(80, cy + 3, 340, 16, cp / 100.0,
            GOOD if cp < 60 else (WARN if cp < 85 else BAD))
        text(f"{cp:5.1f}%", 434, cy + 2, 15, TXT)
        info = f"{p['cpu_count']} logical"
        if p["cpu_freq_mhz"] > 0:
            info += f"  @ {p['cpu_freq_mhz']:.0f} MHz"
        text(info, 32, cy + 24, 12, FAINT)

        cores = p.get("cpu_per_core") or []
        if cores:
            cols = 8
            bx0, by0 = 32, cy + 46
            cw, chh = 52, 8
            for i, v in enumerate(cores[:16]):
                col, row = i % cols, i // cols
                bx = bx0 + col * (cw + 8)
                by = by0 + row * (chh + 14)
                text(str(i), bx, by - 2, 10, FAINT)
                bar(bx + 13, by + 1, cw - 13, chh, v / 100.0,
                    GOOD if v < 60 else (WARN if v < 85 else BAD))

        ry = y + 136
        text("RAM", 32, ry + 2, 15, TXT)
        rp = max(0.0, min(100.0, p["ram_pct"]))
        bar(80, ry + 3, 340, 16, rp / 100.0,
            GOOD if rp < 70 else (WARN if rp < 90 else BAD))
        text(f"{rp:5.1f}%", 434, ry + 2, 15, TXT)
        text(f"{p['ram_used_mb']:.0f} / {p['ram_total_mb']:.0f} MB used",
             32, ry + 24, 12, FAINT)

        py = y + 180
        text("Our process", 32, py + 2, 13, DIM)
        text(f"RSS {p['proc_rss_mb']:.0f} MB    "
             f"CPU {p['proc_cpu_pct']:.1f}%    "
             f"threads {p['proc_threads']}",
             130, py + 2, 13, TXT)

        y += 228

        panel(20, y, 520, 126)
        text("GPU", 32, y + 8, 12, FAINT)
        gname = p["gpu_name"] or "(none detected)"
        text(fit(gname, 16, 496), 32, y + 26, 16, TXT)

        if p["gpu_vram_total_mb"] > 0:
            vy = y + 54
            frac = p["gpu_vram_used_mb"] / max(1.0, p["gpu_vram_total_mb"])
            text("VRAM", 32, vy + 2, 14, DIM)
            bar(90, vy + 3, 320, 14, frac, PURP)
            text(f"{p['gpu_vram_used_mb']:.0f}/{p['gpu_vram_total_mb']:.0f} MB",
                 420, vy + 2, 12, TXT)
            uy = y + 80
            u = p["gpu_util_pct"]
            text("Util", 32, uy + 2, 14, DIM)
            bar(90, uy + 3, 320, 14, max(0.0, min(1.0, u / 100.0)),
                GOOD if u < 60 else (WARN if u < 85 else BAD))
            text(f"{u:.0f}%" if u >= 0 else "n/a", 420, uy + 2, 12, TXT)
            if p["gpu_temp_c"] > 0:
                text(f"{p['gpu_temp_c']:.0f} C", 490, uy + 2, 13, WARN)
        else:
            iy = y + 54
            dn = device_name
            if dn == "legacy":
                text("Legacy AMD path (DirectML)", 32, iy, 14, PURP)
                text("VRAM stats require nvidia-smi or ROCm",
                     32, iy + 20, 12, FAINT)
            elif dn == "dml":
                text("DirectML backend active", 32, iy, 14, PURP)
                text("torch-directml does not expose VRAM totals",
                     32, iy + 20, 12, FAINT)
            elif dn == "cuda":
                text("CUDA active but nvidia-smi not on PATH",
                     32, iy, 14, WARN)
            else:
                text("Running on CPU", 32, iy, 14, DIM)
                text("Vision net has no GPU allocation",
                     32, iy + 20, 12, FAINT)
            text(f"torch: allocated {p['torch_alloc_mb']:.1f} MB, "
                 f"reserved {p['torch_reserved_mb']:.1f} MB",
                 32, iy + 42, 13, TXT)

        y += 138

        panel(20, y, 520, 88)
        text("NEURAL NETWORK", 32, y + 8, 12, FAINT)
        text(f"Parameters: {p['nn_params']:,}", 32, y + 28, 14, TXT)
        text(f"Weights: {p['nn_size_mb']:.2f} MB  (float32)", 32, y + 48, 14, TXT)
        text(f"Running on: {s.get('device_name', device_name)}",
             32, y + 66, 13, DIM)

        y += 100

        n_models = len(p["ollama"])
        rows_h = max(1, n_models) * 22
        h = 34 + rows_h + 8
        panel(20, y, 520, h)
        text("OLLAMA  (loaded models)", 32, y + 8, 12, FAINT)
        if p["ollama_total_mb"] > 0:
            tot = f"total {p['ollama_total_mb']:.0f} MB"
            text(tot, 540 - 12 - tw(tot, 11), y + 8, 11, FAINT)
        if not n_models:
            text("(no models currently loaded)", 32, y + 32, 14, DIM)
        else:
            iy = y + 28
            for m in p["ollama"]:
                name = m["name"]
                size = m["size_mb"]
                vram = m["vram_mb"]
                text(fit(name, 14, 240), 32, iy, 14, TXT)
                if vram > 0.5:
                    text(f"{vram:.0f} MB VRAM", 286, iy, 13, PURP)
                    if size - vram > 1.0:
                        text(f"+{size - vram:.0f} MB RAM",
                             400, iy, 13, FAINT)
                else:
                    text(f"{size:.0f} MB RAM", 286, iy, 13, WARN)
                iy += 22

        y += h + 6
        age = max(0.0, time.time() - p["updated"])
        text(f"updated {age:.1f}s ago", 32, y, 11, FAINT)

    def draw_settings(s):
        ui["hint"] = ""
        y = 56
        sections = []
        for sp in SETTINGS_SPEC:
            if not sections or sections[-1][0] != sp[0]:
                sections.append((sp[0], []))
            sections[-1][1].append(sp)
        for title, rows in sections:
            h = 28 + len(rows) * 36 + 6
            panel(20, y, 520, h)
            text(title.upper(), 32, y + 8, 12, FAINT)
            for i, sp in enumerate(rows):
                ry = y + 26 + i * 36
                _sec, label, key, step, mn, mx_, dec, hint = sp
                rh = hover(20, ry, 520, 34)
                if rh:
                    ui["hint"] = hint
                    rrect(26, ry, 508, 34, (255, 255, 255), 6, 8)
                text(label, 36, ry + 9, 15, TXT)
                if step is None:
                    on = bool(live_settings[key])
                    switch(250, ry + 6, on)
                    text("ON" if on else "OFF", 304, ry + 9, 15,
                         GOOD if on else BAD)
                    if rh:
                        inp["hot"] = True
                        if inp["pressed"]:
                            live_settings[key] = not on
                            save_settings()
                elif isinstance(step, list):
                    choice_row(250, ry + 5, 260, key, step)
                else:
                    if button(250, ry + 5, 24, 24, "-", size=16):
                        set_setting(key, live_settings[key] - step)
                        save_settings()
                    slider(282, ry + 5, 140, key)
                    if button(430, ry + 5, 24, 24, "+", size=16):
                        set_setting(key, live_settings[key] + step)
                        save_settings()
                    text(fmt_value(key), 466, ry + 9, 15, ACC)
            y += h + 8

        hint_y = y
        rrect(20, hint_y, 520, 30, PANEL_HI, 6)
        if ui["toast"] and time.time() < ui["toast_until"]:
            text(ui["toast"], 32, hint_y + 8, 14, GOOD)
        else:
            text(fit(ui["hint"] or "Hover a setting for details. Changes save automatically.",
                     14, 496), 32, hint_y + 8, 14, DIM)
        y = hint_y + 38
        if button(20, y, 170, 30, "Reset to defaults", base=(70, 40, 46)):
            for k, v in SETTINGS_DEFAULTS.items():
                live_settings[k] = v
            save_settings()
            pending_actions.append(("device", live_settings["device_mode"]))
            toast("Settings reset to defaults")
        text(SETTINGS_FILE, 204, y + 8, 13, FAINT)
        y += 40

        panel(20, y, 520, 148)
        text("SYSTEM", 32, y + 8, 12, FAINT)
        gt = game_title if game_hwnd else "(not found)"
        dn = s.get("device_name", device_name)
        dev_str = dn
        if dn == "cuda":
            dev_str += " (NVIDIA GPU / ROCm)"
        elif dn == "dml":
            dev_str += " (AMD/Intel GPU via DirectML)"
        elif dn == "legacy":
            backend = "DirectML" if DIRECTML_AVAILABLE else (
                "ROCm" if CUDA_AVAILABLE else "CPU")
            dev_str += f" (legacy AMD via {backend})"
        else:
            dev_str += " (CPU)"
        gfx = s.get("amd_gfx", "")
        if gfx:
            dev_str += f"  [{gfx}]"
        avail = []
        avail.append("CUDA " + ("yes" if CUDA_AVAILABLE else "no"))
        avail.append("DML " + ("yes" if DIRECTML_AVAILABLE else "no"))
        avail.append("legacy AMD " + ("yes" if LEGACY_AMD_GPU else "no"))
        sys_rows = [
            ("Decision model", LLM_MODEL or "(none - heuristic)"),
            ("Vision model", LLM_VISION_MODEL if VISION_AVAILABLE else "(unavailable)"),
            ("Compute device", dev_str),
            ("Backends", "  ".join(avail)),
            ("Recordings", f"{len(recording_files)} files, "
                           f"{total_frames_saved} frames on disk"),
            ("Game window", gt or "(not found)"),
        ]
        for i, (k, v) in enumerate(sys_rows):
            text(k, 32, y + 28 + i * 20, 14, DIM)
            text(fit(v, 14, 370), 160, y + 28 + i * 20, 14, TXT)
        y += 156 + 20

        panel(20, y, 520, 112)
        text("HOTKEYS", 32, y + 8, 12, FAINT)
        keys = [("F8", "Hand over / take back control"), ("F7", "Retrain (while recording)"),
                ("F9", "Pause / resume"), ("F10", "Quit"),
                ("Insert", "Label: explore"), ("Home", "Label: mine"),
                ("PgUp", "Label: build")]
        for i, (k, d) in enumerate(keys):
            colx = 32 if i < 4 else 290
            ky = y + 28 + (i % 4) * 20
            kw = tw(k, 12) + 14
            rrect(colx, ky, kw, 18, PANEL_HI, 4)
            text(k, colx + 7, ky + 3, 12, TXT)
            text(fit(d, 13, 528 - (colx + kw + 8)), colx + kw + 8, ky + 2, 13, DIM)

    def do_send():
        t = ui["prompt_text"].strip()
        if t:
            send_prompt(t)
            ui["prompt_text"] = ""

    def draw_prompt(s):
        text("ASK / TELL TRUMAN", PROMPT_X, VIZ_H - 114, 12, FAINT)
        active = ui["prompt_active"]
        rrect(PROMPT_X - 1, PROMPT_Y - 1, PROMPT_W + 2, PROMPT_H + 2,
              ACC if active else EDGE, 7)
        rrect(PROMPT_X, PROMPT_Y, PROMPT_W, PROMPT_H, (36, 42, 58) if active else PANEL, 6)
        t = ui["prompt_text"]
        shown = t
        while shown and tw(shown, 16) > PROMPT_W - 24:
            shown = shown[1:]
        if not t and not active:
            text("Click, type, press Enter - try: go mine some stone", PROMPT_X + 12,
                 PROMPT_Y + 10, 14, FAINT)
        text(shown, PROMPT_X + 12, PROMPT_Y + 9, 16, TXT)
        if active and (rl.get_time() % 1.0) < 0.55:
            cx = PROMPT_X + 12 + tw(shown, 16) + 1
            rl.draw_rectangle(int(cx), PROMPT_Y + 7, 2, 20, K(TXT))
        if button(SEND_X, PROMPT_Y, SEND_W, PROMPT_H, "Send", base=(60, 100, 190), size=15):
            do_send()
        if ui["prompt_last"]:
            text(fit(f"you: {ui['prompt_last']}", 14, 520), PROMPT_X, VIZ_H - 46, 14,
                 (180, 180, 220))
        if ui["prompt_response"]:
            col = DIM if ui["prompt_pending"] else WARN
            text(fit(f"{NAME}: {ui['prompt_response']}", 14, 520), PROMPT_X, VIZ_H - 26, 14, col)
        elif ui["prompt_pending"]:
            text(f"{NAME}: ...", PROMPT_X, VIZ_H - 26, 14, DIM)

    while not rl.window_should_close() and not stop[0]:
        try:
            wp = rl.get_window_position()
            viz["viz_x"] = int(wp.x)
            viz["viz_y"] = int(wp.y)
        except Exception:
            pass

        inp["hot"] = False
        _mp = rl.get_mouse_position()
        inp["x"], inp["y"] = _mp.x, _mp.y
        inp["pressed"] = rl.is_mouse_button_pressed(rl.MOUSE_BUTTON_LEFT)
        inp["down"] = rl.is_mouse_button_down(rl.MOUSE_BUTTON_LEFT)
        inp["released"] = rl.is_mouse_button_released(rl.MOUSE_BUTTON_LEFT)
        try:
            inp["wheel"] = float(rl.get_mouse_wheel_move())
        except Exception:
            inp["wheel"] = 0.0

        if inp["pressed"]:
            ui["prompt_active"] = (PROMPT_X <= inp["x"] <= PROMPT_X + PROMPT_W and
                                   PROMPT_Y <= inp["y"] <= PROMPT_Y + PROMPT_H)

        if ui["prompt_active"]:
            ch = rl.get_char_pressed()
            while ch > 0:
                if 32 <= ch < 127 and len(ui["prompt_text"]) < 120:
                    ui["prompt_text"] += chr(ch)
                ch = rl.get_char_pressed()
            back = rl.is_key_pressed(rl.KEY_BACKSPACE)
            try:
                back = back or rl.is_key_pressed_repeat(rl.KEY_BACKSPACE)
            except Exception:
                pass
            if back and ui["prompt_text"]:
                ui["prompt_text"] = ui["prompt_text"][:-1]
            ctrl = rl.is_key_down(rl.KEY_LEFT_CONTROL) or rl.is_key_down(rl.KEY_RIGHT_CONTROL)
            if ctrl and rl.is_key_pressed(rl.KEY_V):
                try:
                    clip = rl.get_clipboard_text()
                    if isinstance(clip, bytes):
                        clip = clip.decode("utf-8", "ignore")
                    clip = "".join(c for c in str(clip) if 32 <= ord(c) < 127)
                    ui["prompt_text"] = (ui["prompt_text"] + clip)[:120]
                except Exception:
                    pass
            if rl.is_key_pressed(rl.KEY_UP) and not ui["prompt_text"] and ui["prompt_last"]:
                ui["prompt_text"] = ui["prompt_last"]
            if rl.is_key_pressed(rl.KEY_ENTER):
                do_send()
            if rl.is_key_pressed(rl.KEY_ESCAPE):
                ui["prompt_active"] = False
                ui["prompt_text"] = ""
        else:
            while rl.get_char_pressed() > 0:
                pass

        s = dict(viz)
        frame, sal = s["frame"], s["sal"]
        if frame is not None:
            upload(tex_in, frame)
            if sal is not None:
                heat = sal[:, :, None] * np.array([255, 80, 0]) * 0.9
                sal_img = np.clip(frame * 0.5 + heat, 0, 255).astype(np.uint8)
                upload(tex_sal, sal_img)
            else:
                upload(tex_sal, (frame * 0.25).astype(np.uint8))

        rl.begin_drawing()
        rl.clear_background(K(BG))
        draw_header(s)
        if ui["tab"] == 0:
            draw_live(s)
            draw_prompt(s)
        elif ui["tab"] == 1:
            draw_mind(s)
            draw_prompt(s)
        elif ui["tab"] == 2:
            draw_brain(s)
            draw_prompt(s)
        elif ui["tab"] == 3:
            draw_perf(s)
            draw_prompt(s)
        else:
            draw_settings(s)
        rl.end_drawing()

        if ui["drag"] is not None and not inp["down"]:
            ui["drag"] = None
            save_settings()
        try:
            rl.set_mouse_cursor(rl.MOUSE_CURSOR_POINTING_HAND if inp["hot"]
                                else rl.MOUSE_CURSOR_DEFAULT)
        except Exception:
            pass

    rl.close_window()


worker = threading.Thread(target=worker_main, daemon=True)
worker.start()
try:
    if VIZ:
        try:
            run_viz()
        except Exception:
            print("\n=== VIZ ERROR ===")
            traceback.print_exc()
        stop[0] = True
    while worker.is_alive():
        worker.join(0.5)
except KeyboardInterrupt:
    print("\nStopped.")
    stop[0] = True
    worker.join(5)

try:
    input("Press Enter to close...")
except Exception:
    pass