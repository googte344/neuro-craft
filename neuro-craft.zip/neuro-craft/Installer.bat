@echo off
setlocal enabledelayedexpansion
title Truman AI - Installer

echo ============================================================
echo    Truman AI - Dependency Installer
echo ============================================================
echo.
echo This will install everything needed to run the Truman AI script:
echo   Required : numpy, mss, torch, pydirectinput, pillow, pynput
echo   Optional : psutil (Perf tab), raylib (visualizer window)
echo   Optional : torch-directml (AMD GPU acceleration)
echo.
echo This may take 5-15 minutes and download ~2-3 GB.
echo.
pause

REM ------------------------------------------------------------------
REM 1. Check Python
REM ------------------------------------------------------------------
echo.
echo [1/7] Checking for Python...
where python >nul 2>nul
if errorlevel 1 (
    echo.
    echo [ERROR] Python is not installed or not on your PATH.
    echo.
    echo   Download Python 3.10 or newer from:
    echo       https://www.python.org/downloads/
    echo.
    echo   IMPORTANT: During install, tick "Add Python to PATH".
    echo.
    pause
    exit /b 1
)

for /f "tokens=2" %%v in ('python --version 2^>^&1') do set PYVER=%%v
echo   Found Python %PYVER%

REM Warn if Python is too old (need 3.8+ for the script).
python -c "import sys; sys.exit(0 if sys.version_info >= (3,8) else 1)"
if errorlevel 1 (
    echo [ERROR] Python 3.8 or newer is required.
    pause
    exit /b 1
)

REM ------------------------------------------------------------------
REM 2. Upgrade pip / build tools
REM ------------------------------------------------------------------
echo.
echo [2/7] Upgrading pip, setuptools, wheel...
python -m pip install --upgrade pip setuptools wheel
if errorlevel 1 (
    echo [WARNING] pip upgrade reported an error - continuing anyway.
)

REM ------------------------------------------------------------------
REM 3. Required packages (lightweight)
REM ------------------------------------------------------------------
echo.
echo [3/7] Installing core dependencies...
python -m pip install numpy mss pynput pydirectinput pillow
if errorlevel 1 (
    echo.
    echo [ERROR] Core dependency install failed.
    echo Try running this installer as Administrator, or check your network.
    pause
    exit /b 1
)

REM ------------------------------------------------------------------
REM 4. PyTorch  (the big one)
REM ------------------------------------------------------------------
echo.
echo [4/7] Installing PyTorch...
echo.
echo   Choose a build:
echo     [1] CPU only        (smallest, ~200 MB - works everywhere)
echo     [2] NVIDIA CUDA 12  (large, ~2.5 GB - for NVIDIA GPUs)
echo     [3] Skip            (if torch is already installed)
echo.
set /p TORCH_CHOICE="  Enter 1, 2 or 3 [default 1]: "
if "%TORCH_CHOICE%"=="" set TORCH_CHOICE=1

if "%TORCH_CHOICE%"=="1" (
    echo   Installing CPU-only PyTorch...
    python -m pip install torch --index-url https://download.pytorch.org/whl/cpu
    if errorlevel 1 (
        echo   [WARN] CPU wheel install failed, falling back to default PyPI...
        python -m pip install torch
    )
) else if "%TORCH_CHOICE%"=="2" (
    echo   Installing CUDA 12 PyTorch...
    python -m pip install torch --index-url https://download.pytorch.org/whl/cu121
    if errorlevel 1 (
        echo   [WARN] CUDA wheel install failed, falling back to default PyPI...
        python -m pip install torch
    )
) else (
    echo   Skipping PyTorch install.
)

REM Verify torch
python -c "import torch" >nul 2>nul
if errorlevel 1 (
    echo.
    echo [ERROR] PyTorch is not importable. The script cannot run without it.
    pause
    exit /b 1
)

REM ------------------------------------------------------------------
REM 5. Optional: psutil + raylib
REM ------------------------------------------------------------------
echo.
echo [5/7] Installing optional packages (psutil, raylib)...
python -m pip install psutil raylib
if errorlevel 1 (
    echo   [WARN] One or both of psutil/raylib failed to install.
    echo          The script still runs, but:
    echo            - without psutil   the Perf tab is limited
    echo            - without raylib   the visualizer window is disabled
)

REM ------------------------------------------------------------------
REM 6. Optional: AMD DirectML  (RX 5700 XT, RX 580, etc.)
REM ------------------------------------------------------------------
echo.
echo [6/7] AMD GPU acceleration?
echo.
echo   If you have an AMD GPU (RX 5700 XT, RX 580, RX 570, Polaris, etc.)
echo   you can install torch-directml for GPU acceleration of the neural
echo   network in the visualizer.
echo.
echo   WARNING: torch-directml REPLACES the standard torch install.
echo            Do NOT do this if you already use torch for NVIDIA/CUDA work.
echo.
set /p AMD_CHOICE="  Install torch-directml now? (y/N): "
if /i "%AMD_CHOICE%"=="y" (
    echo   Removing standard torch...
    python -m pip uninstall -y torch torch-directml
    echo   Installing torch-directml...
    python -m pip install torch-directml
    if errorlevel 1 (
        echo   [ERROR] torch-directml install failed.
        echo   Re-installing standard CPU torch so the script still works...
        python -m pip install torch --index-url https://download.pytorch.org/whl/cpu
    )
) else (
    echo   Skipping DirectML.
)

REM ------------------------------------------------------------------
REM 7. Create data directory + verify everything
REM ------------------------------------------------------------------
echo.
echo [7/7] Creating data directory and verifying install...

if not exist "%USERPROFILE%\Documents\classicube_data" (
    mkdir "%USERPROFILE%\Documents\classicube_data"
    echo   Created %USERPROFILE%\Documents\classicube_data
) else (
    echo   Data directory already exists.
)

echo.
echo   --- Import check ---
python -c "import numpy;       print('   numpy        OK', numpy.__version__)"
python -c "import mss;         print('   mss          OK')"
python -c "import pydirectinput; print('   pydirectinput OK')"
python -c "import pynput;      print('   pynput       OK')"
python -c "import PIL;         print('   pillow       OK', PIL.__version__)"
python -c "import torch;       print('   torch        OK', torch.__version__)"
python -c "import psutil;      print('   psutil       OK', psutil.__version__)" 2>nul || echo    psutil       MISSING (optional)
python -c "import pyray;       print('   raylib       OK')" 2>nul || echo    raylib       MISSING (optional)
python -c "import torch_directml; print('   torch-directml OK')" 2>nul || echo    torch-directml not installed (optional)

REM Check for Ollama
echo.
where ollama >nul 2>nul
if errorlevel 1 (
    echo   Ollama not found on PATH.
    echo     The script expects Ollama at http://localhost:11434
    echo     Download it from: https://ollama.com/download
    echo     After installing Ollama, the script will auto-pull:
    echo         qwen3-vl:2b   (vision)
    echo         qwen2.5:3b / 1.5b / 0.5b  (decision, whatever fits)
) else (
    echo   Ollama found:
    ollama --version
)

REM ------------------------------------------------------------------
REM Done
REM ------------------------------------------------------------------
echo.
echo ============================================================
echo    Installation complete!
echo ============================================================
echo.
echo To run Truman AI:
echo.
echo   1. Start Ollama (it runs in the tray / background)
echo   2. Launch ClassiCube and leave it running
echo   3. In a terminal, run:
echo.
echo         python truman.py
echo.
echo   Hotkeys:
echo     F8  = hand over / take back control
echo     F7  = retrain on the current recording
echo     F9  = pause / resume
echo     F10 = quit
echo.
echo   Recordings and model.pt are saved in:
echo     %USERPROFILE%\Documents\classicube_data
echo.
pause
endlocal